"""
hei_pipeline/run_pipeline.py
==============================
Master Pipeline Runner

Executes all five pipeline modules in order:
  Module 1: Load and clean raw CSV files
  Module 2: Social network analysis (RQ1)
  Module 3: RoBERTa sentiment analysis (RQ2)
  Module 4: Generate all figures (Figs 4.1–4.7)
  Module 5: Generate data sources report

Usage
-----
  # Full pipeline (all modules)
  python run_pipeline.py

  # Skip sentiment (if transformers not installed)
  python run_pipeline.py --skip-sentiment

  # Run only cleaning + figures (load from existing scored file)
  python run_pipeline.py --only-figures

  # Run only data sources report
  python run_pipeline.py --only-sources

Setup
-----
  pip install pandas numpy networkx matplotlib seaborn scipy tqdm
  pip install transformers torch          # required for Module 3 only
  pip install vaderSentiment              # optional fallback

File structure
--------------
  run_pipeline.py          ← this file
  01_load_and_clean.py
  02_network_analysis.py
  03_sentiment_analysis.py
  04_generate_figures.py
  05_data_sources.py

  dataset_comments.csv     ← raw input (place in same folder)
  dataset_posts.csv
  dataset_network_edges.csv
  dataset_users.csv

  cleaned/                 ← created by Module 1
  outputs/                 ← created by Modules 2–3 and 5
  figures/                 ← created by Module 4
"""

import sys
import os
import time
import argparse

sys.path.insert(0, os.path.dirname(__file__))


def banner(title, module_num=None):
    width = 68
    prefix = f"MODULE {module_num} — " if module_num else ""
    print("\n" + "═" * width)
    print(f"  {prefix}{title}")
    print("═" * width)


def elapsed(start):
    s = time.time() - start
    return f"{int(s//60)}m {int(s%60)}s" if s >= 60 else f"{s:.1f}s"


def run_pipeline(skip_sentiment=False, only_figures=False, only_sources=False):
    total_start = time.time()

    if only_sources:
        banner("Data Sources Report", 5)
        t = time.time()
        from hei_pipeline.05_data_sources import generate_report
        generate_report()
        print(f"  Completed in {elapsed(t)}")
        return

    if only_figures:
        banner("Generate Figures", 4)
        t = time.time()
        from hei_pipeline.04_generate_figures import generate_all_figures
        generate_all_figures()
        print(f"  Completed in {elapsed(t)}")
        return

    # ── Module 1: Load and clean ───────────────────────────────────
    banner("Load and Clean Raw Data", 1)
    t = time.time()
    from hei_pipeline.01_load_and_clean import load_and_clean
    comments, posts, edges, users = load_and_clean(save=True)
    print(f"  Completed in {elapsed(t)}")
    print(f"  Comments: {len(comments):,}  Posts: {len(posts):,}  "
          f"Edges: {len(edges):,}  Users: {len(users):,}")

    # ── Module 2: Network analysis ─────────────────────────────────
    banner("Social Network Analysis (RQ1)", 2)
    t = time.time()
    from hei_pipeline.02_network_analysis import run_analysis
    gephi_nodes, gephi_edges, summary = run_analysis()
    print(f"  Completed in {elapsed(t)}")
    print(f"  Nodes: {len(gephi_nodes):,}  Edges: {len(gephi_edges):,}")

    # ── Module 3: Sentiment ────────────────────────────────────────
    if not skip_sentiment:
        banner("RoBERTa Sentiment Analysis (RQ2)", 3)
        t = time.time()
        try:
            from hei_pipeline.03_sentiment_analysis import run_sentiment
            df_scored, cross = run_sentiment()
            print(f"  Completed in {elapsed(t)}")
            print(f"  Scored: {len(df_scored):,} comments")
            print(f"  χ²(2) = {cross['chi2_stat']:.2f}, p = {cross['chi2_p']:.6f}")
        except RuntimeError as e:
            print(f"  SKIPPED: {e}")
            print("  Install with: pip install transformers torch")
    else:
        banner("Sentiment Analysis — SKIPPED (--skip-sentiment flag)", 3)

    # ── Module 4: Figures ──────────────────────────────────────────
    banner("Generate All Figures (Figs 4.1–4.7)", 4)
    t = time.time()
    from hei_pipeline.04_generate_figures import generate_all_figures
    generate_all_figures()
    print(f"  Completed in {elapsed(t)}")

    # ── Module 5: Data sources ─────────────────────────────────────
    banner("Data Sources Report", 5)
    t = time.time()
    from hei_pipeline.05_data_sources import generate_report
    generate_report()
    print(f"  Completed in {elapsed(t)}")

    # ── Summary ────────────────────────────────────────────────────
    print("\n" + "═" * 68)
    print(f"  PIPELINE COMPLETE  —  Total time: {elapsed(total_start)}")
    print("═" * 68)
    print("\n  Output directories:")
    for d in ["cleaned", "outputs", "figures"]:
        if os.path.exists(d):
            n = len(os.listdir(d))
            print(f"    {d}/  ({n} files)")
    print()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="HEI Pipeline Runner — runs all modules in order"
    )
    parser.add_argument("--skip-sentiment", action="store_true",
                        help="Skip Module 3 (requires transformers/torch)")
    parser.add_argument("--only-figures",   action="store_true",
                        help="Run Module 4 only (load from existing outputs)")
    parser.add_argument("--only-sources",   action="store_true",
                        help="Run Module 5 only (data sources report)")
    args = parser.parse_args()
    run_pipeline(
        skip_sentiment=args.skip_sentiment,
        only_figures=args.only_figures,
        only_sources=args.only_sources,
    )
