"""
hei_pipeline/05_data_sources.py
=================================
Module 5 — Data Sources Report Generator

Purpose
-------
Generates a complete data provenance report documenting:
  - All raw data sources (subreddits, collection period, API)
  - All derived datasets produced by each pipeline module
  - All statistical values embedded in the figures
  - All literature references cited in the methodology

Output
------
  outputs/data_sources_report.csv   — machine-readable provenance table
  outputs/data_sources_report.txt   — human-readable full report

Usage
-----
  python 05_data_sources.py
"""

import os
import pandas as pd
from datetime import datetime

OUTPUT_DIR = "outputs"

# ─────────────────────────────────────────────────────────────────────────────
# RAW DATA SOURCES
# ─────────────────────────────────────────────────────────────────────────────
RAW_SOURCES = [
    {
        "Source_ID":       "RAW-01",
        "Type":            "Raw dataset",
        "Name":            "dataset_comments.csv",
        "Description":     "All comments scraped from the four HEI subreddits using PRAW",
        "Subreddits":      "r/Benilde, r/dlsu, r/peyups, r/AdMU",
        "Rows_Raw":        35782,
        "Rows_Clean":      30229,
        "Columns":         "subreddit, post_id, post_title, comment_id, comment_body, "
                          "comment_author, comment_score, comment_parent_id, "
                          "comment_depth, comment_created_utc, tie_strength_proxy",
        "Date_Range":      "2021-05-17 to 2026-05-03",
        "Collection_Tool": "PRAW (Python Reddit API Wrapper) v7.x",
        "API":             "Reddit API v1 (OAuth2, script-type application)",
        "Sort_Methods":    "new, hot, top",
        "Ethical_Note":    "Public data only; usernames pseudonymized in analysis; "
                          "Reddit API Terms of Service compliant",
        "Reference":       "Shatz (2017); Proferes et al. (2021)",
    },
    {
        "Source_ID":       "RAW-02",
        "Type":            "Raw dataset",
        "Name":            "dataset_posts.csv",
        "Description":     "All posts scraped from the four HEI subreddits",
        "Subreddits":      "r/Benilde, r/dlsu, r/peyups, r/AdMU",
        "Rows_Raw":        2105,
        "Rows_Clean":      2044,
        "Columns":         "subreddit, post_id, post_title, post_body, post_author, "
                          "post_score, post_upvote_ratio, post_url, post_num_comments, "
                          "post_created_utc, post_flair, sort_method",
        "Date_Range":      "2021-05-14 to 2026-05-03",
        "Collection_Tool": "PRAW v7.x",
        "API":             "Reddit API v1 (OAuth2)",
        "Sort_Methods":    "new, hot, top",
        "Ethical_Note":    "Public data; no personal information collected beyond username",
        "Reference":       "Shatz (2017)",
    },
    {
        "Source_ID":       "RAW-03",
        "Type":            "Raw dataset",
        "Name":            "dataset_network_edges.csv",
        "Description":     "Directed interaction edges (reply graph) derived from comment parent IDs",
        "Subreddits":      "r/Benilde, r/dlsu, r/peyups, r/AdMU",
        "Rows_Raw":        35782,
        "Rows_Clean":      21530,
        "Columns":         "source, target, edge_type, weight, post_id, "
                          "subreddit, depth, timestamp",
        "Date_Range":      "2021-05-17 to 2026-05-03",
        "Collection_Tool": "Derived from dataset_comments.csv via PRAW comment.parent_id",
        "API":             "Reddit API v1",
        "Sort_Methods":    "N/A — derived dataset",
        "Ethical_Note":    "Interaction graph; no content data; fully pseudonymous",
        "Reference":       "Borbon & Ebardo (2025); Chen & Cheng (2022)",
    },
    {
        "Source_ID":       "RAW-04",
        "Type":            "Raw dataset",
        "Name":            "dataset_users.csv",
        "Description":     "Aggregated user activity profile with cross-subreddit bridge flag",
        "Subreddits":      "r/Benilde, r/dlsu, r/peyups, r/AdMU",
        "Rows_Raw":        11483,
        "Rows_Clean":      11483,
        "Columns":         "user, subreddits_active, num_subreddits, total_activity, is_bridge_user",
        "Date_Range":      "2021-05-17 to 2026-05-03",
        "Collection_Tool": "Aggregated from dataset_comments.csv by scraper",
        "API":             "N/A — derived from PRAW data",
        "Sort_Methods":    "N/A",
        "Ethical_Note":    "Usernames are Reddit pseudonyms; no real-name data collected",
        "Reference":       "Granovetter (1973); Proferes et al. (2021)",
    },
]

# ─────────────────────────────────────────────────────────────────────────────
# DERIVED / PROCESSED DATASETS
# ─────────────────────────────────────────────────────────────────────────────
DERIVED_SOURCES = [
    {
        "Source_ID":    "DER-01",
        "Type":         "Cleaned dataset",
        "Name":         "cleaned/comments_clean.csv",
        "Description":  "Comments after removing bots, deleted content, duplicates",
        "Produced_by":  "01_load_and_clean.py",
        "Input":        "dataset_comments.csv",
        "Rows":         30229,
        "Key_additions":"tie_type (weak/strong), year, month, year_month, score_log",
        "Cleaning_rules":"Remove bot authors (AutoModerator, BotDefense, etc.); "
                        "remove [deleted]/[removed] bodies; deduplicate on comment_id; "
                        "tie_type = 'weak' if tie_strength_proxy > median (1.0), else 'strong'",
    },
    {
        "Source_ID":    "DER-02",
        "Type":         "Cleaned dataset",
        "Name":         "cleaned/posts_clean.csv",
        "Description":  "Posts after removing bots and deduplicating on post_id",
        "Produced_by":  "01_load_and_clean.py",
        "Input":        "dataset_posts.csv",
        "Rows":         2044,
        "Key_additions":"year, month, year_month, thread_tier (low/medium/high/viral)",
        "Cleaning_rules":"Remove bot authors; drop_duplicates on post_id",
    },
    {
        "Source_ID":    "DER-03",
        "Type":         "Cleaned dataset",
        "Name":         "cleaned/edges_clean.csv",
        "Description":  "Edges after removing self-loops, bots, and adding weight_log",
        "Produced_by":  "01_load_and_clean.py",
        "Input":        "dataset_network_edges.csv",
        "Rows":         21530,
        "Key_additions":"weight_log = log(weight+1); tie_type per edge",
        "Cleaning_rules":"Remove self-loops (source==target); remove bot actors; "
                        "remove 'unknown' targets; drop_duplicates",
    },
    {
        "Source_ID":    "DER-04",
        "Type":         "Network analysis output",
        "Name":         "outputs/gephi_nodes_enriched.csv",
        "Description":  "Node-level centrality metrics and interaction aggregates for full network",
        "Produced_by":  "02_network_analysis.py",
        "Input":        "edges_clean.csv, users.csv, comments_clean.csv",
        "Rows":         10801,
        "Key_additions":"degree_centrality, in_degree_centrality, out_degree_centrality, "
                        "betweenness_centrality (k=500), clustering_coefficient, "
                        "in_degree_weighted, out_degree_weighted, total_upvotes_received, "
                        "weak_tie_ratio, size_betweenness (1-100 normalized), "
                        "primary_subreddit, is_bridge_user, Label, Id",
        "Cleaning_rules":"Betweenness approximated at k=500 for computational efficiency; "
                        "exact betweenness available by setting BETWEENNESS_K=None",
    },
    {
        "Source_ID":    "DER-05",
        "Type":         "Network analysis output",
        "Name":         "outputs/gephi_edges_enriched.csv",
        "Description":  "Edge-level data with tie type and log-scaled weight for Gephi import",
        "Produced_by":  "02_network_analysis.py",
        "Input":        "edges_clean.csv",
        "Rows":         21530,
        "Key_additions":"TieType, WeightLog, renamed columns (Source, Target, Weight, etc.)",
        "Cleaning_rules":"Inherits cleaning from edges_clean.csv",
    },
    {
        "Source_ID":    "DER-06",
        "Type":         "Sentiment analysis output",
        "Name":         "outputs/comments_scored.csv",
        "Description":  "All cleaned comments with RoBERTa sentiment scores",
        "Produced_by":  "03_sentiment_analysis.py",
        "Input":        "comments_clean.csv",
        "Rows":         30229,
        "Key_additions":"roberta_label, roberta_neg, roberta_neu, roberta_pos, "
                        "roberta_compound (pos-neg), roberta_confidence (max prob), "
                        "roberta_reliable (confidence >= 0.60)",
        "Cleaning_rules":"Preprocessing: replace u/ and r/ handles with @user; "
                        "replace URLs with http; max_length=128 tokens; batch_size=32",
    },
    {
        "Source_ID":    "DER-07",
        "Type":         "NVivo export",
        "Name":         "outputs/nvivo_sample_bert.csv",
        "Description":  "Stratified 500-comment sample for qualitative NVivo coding",
        "Produced_by":  "03_sentiment_analysis.py",
        "Input":        "comments_scored.csv",
        "Rows":         "~500 (150 high_reach + 150 deep_thread + 100 random + 100 low_confidence)",
        "Key_additions":"sample_type column indicating stratum",
        "Cleaning_rules":"Stratified sampling; deduplicated on comment_id; "
                        "low_confidence = roberta_confidence < 0.60 (Taglish/ambiguous)",
    },
]

# ─────────────────────────────────────────────────────────────────────────────
# EMBEDDED STATISTICAL VALUES (used in figures and text)
# ─────────────────────────────────────────────────────────────────────────────
STATISTICS = [
    # Dataset
    {"Stat_ID":"S01","Figure":"All","Value":"30,229","Description":"Total cleaned comments","Source":"01_load_and_clean.py"},
    {"Stat_ID":"S02","Figure":"All","Value":"2,044","Description":"Total cleaned posts","Source":"01_load_and_clean.py"},
    {"Stat_ID":"S03","Figure":"All","Value":"2021-05-17 to 2026-05-03","Description":"Data collection date range","Source":"dataset_comments.csv"},
    # Network — merged
    {"Stat_ID":"S04","Figure":"Fig 4.1, 4.2","Value":"10,801","Description":"Nodes in merged network","Source":"02_network_analysis.py"},
    {"Stat_ID":"S05","Figure":"Fig 4.1, 4.2","Value":"21,530","Description":"Edges in merged network","Source":"02_network_analysis.py"},
    {"Stat_ID":"S06","Figure":"Fig 4.1","Value":"0.000185","Description":"Network density (merged)","Source":"02_network_analysis.py"},
    {"Stat_ID":"S07","Figure":"Fig 4.1","Value":"0.0764","Description":"Average clustering coefficient (merged)","Source":"02_network_analysis.py"},
    {"Stat_ID":"S08","Figure":"Fig 4.1","Value":"113","Description":"Weakly connected components (merged)","Source":"02_network_analysis.py"},
    {"Stat_ID":"S09","Figure":"Fig 4.1","Value":"97.5%","Description":"% nodes in largest connected component","Source":"02_network_analysis.py"},
    # Network — per HEI
    {"Stat_ID":"S10","Figure":"Fig 4.3","Value":"0.1449","Description":"Clustering coefficient r/AdMU (3× others)","Source":"02_network_analysis.py per-HEI"},
    {"Stat_ID":"S11","Figure":"Fig 4.3","Value":"0.0528","Description":"Clustering coefficient r/Benilde","Source":"02_network_analysis.py per-HEI"},
    {"Stat_ID":"S12","Figure":"Fig 4.3","Value":"0.0550","Description":"Clustering coefficient r/dlsu","Source":"02_network_analysis.py per-HEI"},
    {"Stat_ID":"S13","Figure":"Fig 4.3","Value":"0.0466","Description":"Clustering coefficient r/peyups","Source":"02_network_analysis.py per-HEI"},
    # Granovetter
    {"Stat_ID":"S14","Figure":"Fig 4.4","Value":"13,860 (45.9%)","Description":"Weak-tie comments","Source":"01_load_and_clean.py (tie_type)"},
    {"Stat_ID":"S15","Figure":"Fig 4.4","Value":"16,369 (54.1%)","Description":"Strong-tie comments","Source":"01_load_and_clean.py (tie_type)"},
    {"Stat_ID":"S16","Figure":"Fig 4.4","Value":"0.004062","Description":"Mean betweenness — bridge users","Source":"02_network_analysis.py"},
    {"Stat_ID":"S17","Figure":"Fig 4.4","Value":"0.000668","Description":"Mean betweenness — non-bridge users","Source":"02_network_analysis.py"},
    {"Stat_ID":"S18","Figure":"Fig 4.4","Value":"6.1×","Description":"Bridge/non-bridge betweenness ratio","Source":"02_network_analysis.py"},
    {"Stat_ID":"S19","Figure":"Fig 4.4","Value":"p < .001","Description":"Mann-Whitney U — bridge vs non-bridge (all 3 metrics)","Source":"02_network_analysis.py"},
    {"Stat_ID":"S20","Figure":"Fig 4.4","Value":"χ²(2) = 631.78, p < .001","Description":"Chi-square — sentiment × tie type","Source":"03_sentiment_analysis.py"},
    {"Stat_ID":"S21","Figure":"Fig 4.4","Value":"-0.042","Description":"Mean RoBERTa compound score — weak-tie comments","Source":"03_sentiment_analysis.py"},
    {"Stat_ID":"S22","Figure":"Fig 4.4","Value":"+0.105","Description":"Mean RoBERTa compound score — strong-tie comments","Source":"03_sentiment_analysis.py"},
    # Sentiment
    {"Stat_ID":"S23","Figure":"Fig 4.5","Value":"22.8% positive","Description":"Overall positive sentiment proportion","Source":"03_sentiment_analysis.py"},
    {"Stat_ID":"S24","Figure":"Fig 4.5","Value":"56.0% neutral","Description":"Overall neutral sentiment proportion","Source":"03_sentiment_analysis.py"},
    {"Stat_ID":"S25","Figure":"Fig 4.5","Value":"21.2% negative","Description":"Overall negative sentiment proportion","Source":"03_sentiment_analysis.py"},
    {"Stat_ID":"S26","Figure":"Fig 4.5","Value":"+0.0375","Description":"Overall mean compound score","Source":"03_sentiment_analysis.py"},
    {"Stat_ID":"S27","Figure":"Fig 4.5","Value":"0.747","Description":"Mean RoBERTa classification confidence","Source":"03_sentiment_analysis.py"},
    {"Stat_ID":"S28","Figure":"Fig 4.5","Value":"79.0%","Description":"% comments with confidence >= 0.60","Source":"03_sentiment_analysis.py"},
    # By subreddit
    {"Stat_ID":"S29","Figure":"Fig 4.5b","Value":"r/AdMU: 24.5% pos / 61.5% neu / 14.0% neg","Description":"Sentiment by subreddit — r/AdMU","Source":"03_sentiment_analysis.py"},
    {"Stat_ID":"S30","Figure":"Fig 4.5b","Value":"r/peyups: 20.9% pos / 55.7% neu / 23.4% neg","Description":"Sentiment by subreddit — r/peyups","Source":"03_sentiment_analysis.py"},
    {"Stat_ID":"S31","Figure":"Fig 4.5b","Value":"r/dlsu: 20.7% pos / 52.3% neu / 27.0% neg","Description":"Sentiment by subreddit — r/dlsu","Source":"03_sentiment_analysis.py"},
    {"Stat_ID":"S32","Figure":"Fig 4.5b","Value":"r/Benilde: 24.2% pos / 44.5% neu / 31.2% neg","Description":"Sentiment by subreddit — r/Benilde","Source":"03_sentiment_analysis.py"},
    # Temporal
    {"Stat_ID":"S33","Figure":"Fig 4.6","Value":"3,433","Description":"Top thread comment count (ACET 2025 Megathread, r/AdMU)","Source":"dataset_posts.csv"},
    {"Stat_ID":"S34","Figure":"Fig 4.6","Value":"14.4","Description":"Mean thread length (comments per post) across all HEIs","Source":"posts_clean.csv"},
    {"Stat_ID":"S35","Figure":"Fig 4.6","Value":"50.5% / 49.5%","Description":"post_reply / comment_reply split (depth 0 / depth 1)","Source":"edges_clean.csv"},
    # Bridge users
    {"Stat_ID":"S36","Figure":"Fig 4.4, 4.7","Value":"368 (3.2%)","Description":"Bridge users (active in 2+ HEI subreddits)","Source":"dataset_users.csv"},
    {"Stat_ID":"S37","Figure":"Fig 4.3e","Value":"241 (AdMU), 216 (dlsu), 175 (peyups), 88 (Benilde)","Description":"Bridge users per HEI","Source":"02_network_analysis.py per-HEI"},
]

# ─────────────────────────────────────────────────────────────────────────────
# LITERATURE REFERENCES
# ─────────────────────────────────────────────────────────────────────────────
REFERENCES = [
    {
        "Ref_ID":   "R01",
        "Role":     "Theoretical framework",
        "Citation": "Granovetter, M. (1973). The strength of weak ties. "
                   "American Journal of Sociology, 78(6), 1360–1380. "
                   "https://doi.org/10.1086/225469",
        "Used_in":  "Central theoretical framework; operationalized through tie_type classification "
                   "and bridge user identification",
    },
    {
        "Ref_ID":   "R02",
        "Role":     "Sentiment model",
        "Citation": "Barbieri, F., Camacho-Collados, J., Espinosa Anke, L., & Neves, L. (2020). "
                   "TweetEval: Unified benchmark and comparative evaluation for tweet classification. "
                   "Findings of EMNLP 2020, 1644–1650. https://doi.org/10.18653/v1/2020.findings-emnlp.148",
        "Used_in":  "cardiffnlp/twitter-roberta-base-sentiment-latest model; "
                   "justification for model selection in 03_sentiment_analysis.py",
    },
    {
        "Ref_ID":   "R03",
        "Role":     "Sentiment model (architecture)",
        "Citation": "Liu, Y., Ott, M., Goyal, N., Du, J., Joshi, M., Chen, D., Levy, O., Lewis, M., "
                   "Zettlemoyer, L., & Stoyanov, V. (2019). RoBERTa: A robustly optimized BERT "
                   "pretraining approach. arXiv:1907.11692. "
                   "https://doi.org/10.48550/arXiv.1907.11692",
        "Used_in":  "RoBERTa model architecture; cited in §3.3 instrument justification",
    },
    {
        "Ref_ID":   "R04",
        "Role":     "Sentiment model validation (HEI subreddit)",
        "Citation": "Yan, T., & Liu, F. (2021). Sentiment analysis and effect of COVID-19 pandemic "
                   "using college subreddit data. arXiv:2112.04351. "
                   "https://doi.org/10.48550/arXiv.2112.04351",
        "Used_in":  "Justification that RoBERTa is applicable to HEI subreddit sentiment analysis",
    },
    {
        "Ref_ID":   "R05",
        "Role":     "Sentiment model comparison (VADER vs RoBERTa)",
        "Citation": "Bharadwaj, R., Shendurkar, S., Kadam, T., Patekar, U., & Waghule, S. (2024). "
                   "RoBERTa and VADER sentiment analysis: A comparative approach. "
                   "In Proceedings of the Eighth International Conference on Information System "
                   "Design and Intelligent Applications. Springer. "
                   "https://doi.org/10.1007/978-981-97-8666-4_12",
        "Used_in":  "Empirical comparison showing RoBERTa superiority over VADER on social media text",
    },
    {
        "Ref_ID":   "R06",
        "Role":     "Sarcasm / transformer superiority",
        "Citation": "Memon, M. Q., Banbhrani, S. K., Akhter, M. N., Noureen, F., & Mehreen, F. (2024). "
                   "Detecting sarcasm in social media posts using transformer-based language models "
                   "with contextual and sentiment-aware features. "
                   "Spectrum of Engineering Sciences, 2(5), 534–549. "
                   "https://sesjournal.org/index.php/1/article/view/354",
        "Used_in":  "Justification for transformer over VADER for sarcasm-heavy informal text",
    },
    {
        "Ref_ID":   "R07",
        "Role":     "Network theory (small world / information diffusion)",
        "Citation": "Watts, D. J., & Dodds, P. S. (2007). Influentials, networks, and public opinion "
                   "formation. Journal of Consumer Research, 34(4), 441–458. "
                   "https://doi.org/10.1086/518527",
        "Used_in":  "Discussion of network density and information diffusion in §5.1",
    },
    {
        "Ref_ID":   "R08",
        "Role":     "Reddit data ethics / scraping",
        "Citation": "Proferes, N., Jones, N., Gilbert, S., Fiesler, C., & Zimmer, M. (2021). "
                   "Studying Reddit: A systematic overview of disciplines, approaches, methods, "
                   "and ethics. Social Media + Society, 7(2). "
                   "https://doi.org/10.1177/20563051211019004",
        "Used_in":  "Ethical framework for Reddit data collection in §3.4",
    },
    {
        "Ref_ID":   "R09",
        "Role":     "Reddit scraping methodology",
        "Citation": "Shatz, I. (2017). Fast, free, and targeted: Reddit as a source for recruiting "
                   "participants online. Social Science Computer Review, 35(4), 537–549. "
                   "https://doi.org/10.1177/0894439316650163",
        "Used_in":  "PRAW collection methodology in §3.4",
    },
    {
        "Ref_ID":   "R10",
        "Role":     "VADER (cited as superseded baseline)",
        "Citation": "Hutto, C., & Gilbert, E. (2014). VADER: A parsimonious rule-based model for "
                   "sentiment analysis of social media text. "
                   "Proceedings of ICWSM, 8(1), 216–225.",
        "Used_in":  "Cited in §3.3 to document limitations of lexicon-based approaches superseded "
                   "by RoBERTa in this study",
    },
    {
        "Ref_ID":   "R11",
        "Role":     "Network analysis (social media / online communities)",
        "Citation": "Bakshy, E., Rosenn, I., Marlow, C., & Adamic, L. (2012). "
                   "The role of social networks in information diffusion. "
                   "Proceedings of WWW 2012, 519–528. "
                   "https://doi.org/10.1145/2187836.2187907",
        "Used_in":  "§5.1 discussion of sparse network density as expected in Reddit environments",
    },
    {
        "Ref_ID":   "R12",
        "Role":     "ForceAtlas2 layout algorithm",
        "Citation": "Jacomy, M., Venturini, T., Heymann, S., & Bastian, M. (2014). "
                   "ForceAtlas2, a continuous graph layout algorithm for handy network visualization "
                   "designed for the Gephi software. PLOS ONE, 9(6), e98679. "
                   "https://doi.org/10.1371/journal.pone.0098679",
        "Used_in":  "Gephi ForceAtlas2 layout settings; cited in Gephi replication guide",
    },
    {
        "Ref_ID":   "R13",
        "Role":     "GoEmotions / Reddit sentiment benchmark",
        "Citation": "Demszky, D., Movshovitz-Attias, D., Ko, J., Cowen, A., Nemade, G., & Ravi, S. (2020). "
                   "GoEmotions: A dataset of fine-grained emotions. "
                   "Proceedings of ACL 2020, 4040–4054. "
                   "https://doi.org/10.18653/v1/2020.acl-main.372",
        "Used_in":  "§3.3 — confirms RoBERTa superiority on Reddit comment data",
    },
    {
        "Ref_ID":   "R14",
        "Role":     "Dissertation prior work",
        "Citation": "Borbon, [First Author], & Ebardo, R. (2025). [Title of prior study]. "
                   "[Journal/Conference]. [DOI — insert when published]",
        "Used_in":  "§1 — cited to establish researcher's prior work in HEI social media analysis",
    },
    {
        "Ref_ID":   "R15",
        "Role":     "Anonymous Reddit data / pseudonymity",
        "Citation": "Chen, G. M., & Cheng, M. (2022). Comparing self-disclosure on social media: "
                   "Directness, intimacy, and gender differences. "
                   "Social Media + Society, 8(1). "
                   "https://doi.org/10.1177/20563051221082867",
        "Used_in":  "§3.2 — justification for treating Reddit usernames as pseudonymous",
    },
]


# ─────────────────────────────────────────────────────────────────────────────
# GENERATE REPORT
# ─────────────────────────────────────────────────────────────────────────────
def generate_report():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    lines = []
    lines.append("=" * 72)
    lines.append("DATA SOURCES AND PROVENANCE REPORT")
    lines.append("Beyond the Eval: Exploring Social Media as an Informal")
    lines.append("Lens for Faculty Performance in a Digital Age")
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("=" * 72)

    # ── Raw sources ─────────────────────────────────────────────────
    lines.append("\n" + "─" * 72)
    lines.append("SECTION 1: RAW DATA SOURCES")
    lines.append("─" * 72)
    for s in RAW_SOURCES:
        lines.append(f"\n{s['Source_ID']}: {s['Name']}")
        lines.append(f"  Type          : {s['Type']}")
        lines.append(f"  Description   : {s['Description']}")
        lines.append(f"  Subreddits    : {s['Subreddits']}")
        lines.append(f"  Rows (raw)    : {s['Rows_Raw']:,}")
        lines.append(f"  Rows (clean)  : {s['Rows_Clean']:,}")
        lines.append(f"  Date range    : {s['Date_Range']}")
        lines.append(f"  Collection    : {s['Collection_Tool']}")
        lines.append(f"  API           : {s['API']}")
        lines.append(f"  Sort methods  : {s['Sort_Methods']}")
        lines.append(f"  Ethics note   : {s['Ethical_Note']}")
        lines.append(f"  References    : {s['Reference']}")

    # ── Derived datasets ────────────────────────────────────────────
    lines.append("\n" + "─" * 72)
    lines.append("SECTION 2: DERIVED / PROCESSED DATASETS")
    lines.append("─" * 72)
    for s in DERIVED_SOURCES:
        lines.append(f"\n{s['Source_ID']}: {s['Name']}")
        lines.append(f"  Type          : {s['Type']}")
        lines.append(f"  Description   : {s['Description']}")
        lines.append(f"  Produced by   : {s['Produced_by']}")
        lines.append(f"  Input         : {s['Input']}")
        lines.append(f"  Rows          : {s['Rows']}")
        lines.append(f"  Key additions : {s['Key_additions']}")
        lines.append(f"  Cleaning      : {s['Cleaning_rules']}")

    # ── Statistics ──────────────────────────────────────────────────
    lines.append("\n" + "─" * 72)
    lines.append("SECTION 3: EMBEDDED STATISTICAL VALUES (Figures & Chapter 4)")
    lines.append("─" * 72)
    lines.append(f"\n{'ID':<6} {'Figure':<15} {'Value':<35} {'Description'}")
    lines.append(f"{'─'*6} {'─'*15} {'─'*35} {'─'*30}")
    for s in STATISTICS:
        lines.append(f"{s['Stat_ID']:<6} {s['Figure']:<15} {str(s['Value']):<35} {s['Description']}")
    lines.append(f"\nAll statistical values derived from pipeline modules 01–03.")
    lines.append(f"Source scripts listed in Source column above.")

    # ── References ──────────────────────────────────────────────────
    lines.append("\n" + "─" * 72)
    lines.append("SECTION 4: LITERATURE REFERENCES")
    lines.append("─" * 72)
    for r in REFERENCES:
        lines.append(f"\n{r['Ref_ID']} [{r['Role']}]")
        lines.append(f"  {r['Citation']}")
        lines.append(f"  Used in: {r['Used_in']}")

    lines.append("\n" + "=" * 72)
    lines.append("END OF DATA SOURCES REPORT")
    lines.append("=" * 72)

    report_text = "\n".join(lines)

    # Save text report
    txt_path = os.path.join(OUTPUT_DIR, "data_sources_report.txt")
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(report_text)
    print(f"Text report saved: {txt_path}")

    # Save CSV (statistics table)
    stats_df = pd.DataFrame(STATISTICS)
    csv_path = os.path.join(OUTPUT_DIR, "data_sources_report.csv")
    stats_df.to_csv(csv_path, index=False)
    print(f"CSV table saved: {csv_path}")

    # Save references CSV
    refs_df = pd.DataFrame(REFERENCES)
    refs_path = os.path.join(OUTPUT_DIR, "references.csv")
    refs_df.to_csv(refs_path, index=False)
    print(f"References saved: {refs_path}")

    print(report_text)
    return report_text


if __name__ == "__main__":
    generate_report()
