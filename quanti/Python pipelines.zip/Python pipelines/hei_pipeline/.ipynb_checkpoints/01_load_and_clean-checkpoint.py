"""
hei_pipeline/01_load_and_clean.py
==================================
Module 1 — Data Loading and Cleaning

Dissertation: Beyond the Eval: Exploring Social Media as an Informal
Lens for Faculty Performance in a Digital Age

Purpose
-------
Loads the four raw CSV files produced by the Reddit scraper, applies
consistent cleaning rules, engineers derived columns, and saves cleaned
intermediate files ready for analysis and visualization.

Input files (place in DATA_DIR)
--------------------------------
  dataset_comments.csv
  dataset_posts.csv
  dataset_network_edges.csv
  dataset_users.csv

Output files (saved to OUTPUT_DIR)
------------------------------------
  comments_clean.csv      — 30,229 rows after cleaning
  posts_clean.csv         — 2,044 rows after cleaning
  edges_clean.csv         — 21,530 rows after cleaning
  users.csv               — 11,483 rows (unchanged, bridge flag added)
  pipeline_summary.txt    — human-readable cleaning report

Usage
-----
  python 01_load_and_clean.py

  Or import and call directly:
    from hei_pipeline.load_and_clean import load_and_clean
    comments, posts, edges, users = load_and_clean()
"""

import os
import math
import pandas as pd
import numpy as np
from datetime import datetime

# ── Configuration ─────────────────────────────────────────────────────────────
DATA_DIR   = "."          # folder containing the raw CSV files
OUTPUT_DIR = "cleaned"    # folder where cleaned files are saved

# Known Reddit bot accounts to exclude from all analysis
BOTS = {
    "AutoModerator", "BotDefense", "RepostSleuthBot", "RemindMeBot",
    "MAGIC_EYE_BOT", "anti-gif-bot", "Bot_Metric", "reddit-bot",
    "Deleted", "deleted", "[deleted]",
}

# Subreddit color palette (consistent across all figures)
SUB_COLORS = {
    "Benilde": "#0d6efd",   # Blue  — College of Saint Benilde
    "dlsu":    "#198754",   # Green — De La Salle University
    "peyups":  "#dc3545",   # Red   — University of the Philippines
    "AdMU":    "#fd7e14",   # Amber — Ateneo de Manila University
    "unknown": "#adb5bd",   # Grey  — unclassified
}

# ── Main cleaning function ────────────────────────────────────────────────────

def load_and_clean(data_dir=DATA_DIR, output_dir=OUTPUT_DIR, save=True):
    """
    Load raw CSVs, apply cleaning rules, engineer derived columns.

    Parameters
    ----------
    data_dir  : str — directory containing raw CSV files
    output_dir: str — directory to save cleaned files
    save      : bool — if True, write cleaned files to output_dir

    Returns
    -------
    Tuple of (comments_clean, posts_clean, edges_clean, users)
    """
    os.makedirs(output_dir, exist_ok=True)
    report = []
    report.append(f"HEI Pipeline — Cleaning Report")
    report.append(f"Run at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append("=" * 60)

    # ── 1. Load raw files ─────────────────────────────────────────
    print("Loading raw CSV files...")

    comments = pd.read_csv(
        os.path.join(data_dir, "dataset_comments.csv"),
        parse_dates=["comment_created_utc"],
    )
    posts = pd.read_csv(
        os.path.join(data_dir, "dataset_posts.csv"),
        parse_dates=["post_created_utc"],
    )
    edges = pd.read_csv(
        os.path.join(data_dir, "dataset_network_edges.csv"),
        parse_dates=["timestamp"],
    )
    users = pd.read_csv(os.path.join(data_dir, "dataset_users.csv"))

    report.append(f"\nRAW COUNTS")
    report.append(f"  Comments : {len(comments):>8,}")
    report.append(f"  Posts    : {len(posts):>8,}")
    report.append(f"  Edges    : {len(edges):>8,}")
    report.append(f"  Users    : {len(users):>8,}")

    # ── 2. Clean COMMENTS ─────────────────────────────────────────
    print("Cleaning comments...")
    n_before = len(comments)

    comments_clean = comments.copy()

    # Remove bot authors
    mask_bot = comments_clean["comment_author"].isin(BOTS)
    comments_clean = comments_clean[~mask_bot]

    # Remove deleted / removed content
    mask_del = comments_clean["comment_body"].isin(["[deleted]", "[removed]"])
    comments_clean = comments_clean[~mask_del]

    # Remove null bodies
    mask_null = comments_clean["comment_body"].isna()
    comments_clean = comments_clean[~mask_null]

    # Deduplicate on comment_id
    comments_clean = comments_clean.drop_duplicates(subset=["comment_id"])

    # Engineer derived columns
    # Tie strength classification: weak = above median proxy
    median_proxy = comments_clean["tie_strength_proxy"].median()
    comments_clean["tie_type"] = comments_clean["tie_strength_proxy"].apply(
        lambda x: "weak" if x > median_proxy else "strong"
    )

    # Temporal features
    comments_clean["year"]       = comments_clean["comment_created_utc"].dt.year
    comments_clean["month"]      = comments_clean["comment_created_utc"].dt.month
    comments_clean["year_month"] = comments_clean["comment_created_utc"].dt.to_period("M")

    # Log-scaled comment score (safe: clip negative scores to 0 before log)
    comments_clean["score_log"] = comments_clean["comment_score"].clip(lower=0).apply(
        lambda x: math.log(x + 1)
    )

    n_after = len(comments_clean)
    report.append(f"\nCOMMENTS CLEANING")
    report.append(f"  Before   : {n_before:>8,}")
    report.append(f"  After    : {n_after:>8,}")
    report.append(f"  Removed  : {n_before - n_after:>8,}  "
                  f"({(n_before - n_after)/n_before*100:.1f}%)")
    report.append(f"  Bots     : {mask_bot.sum():>8,}")
    report.append(f"  Deleted  : {mask_del.sum():>8,}")
    report.append(f"  Null     : {mask_null.sum():>8,}")
    report.append(f"  Median proxy (tie threshold): {median_proxy}")
    report.append(f"  Weak ties : {(comments_clean['tie_type']=='weak').sum():>8,}")
    report.append(f"  Strong ties:{(comments_clean['tie_type']=='strong').sum():>8,}")

    # ── 3. Clean POSTS ────────────────────────────────────────────
    print("Cleaning posts...")
    n_before_p = len(posts)

    posts_clean = posts.copy()
    posts_clean = posts_clean[~posts_clean["post_author"].isin(BOTS)]
    posts_clean = posts_clean.drop_duplicates(subset=["post_id"])

    # Temporal features
    posts_clean["year"]       = posts_clean["post_created_utc"].dt.year
    posts_clean["month"]      = posts_clean["post_created_utc"].dt.month
    posts_clean["year_month"] = posts_clean["post_created_utc"].dt.to_period("M")

    # Thread amplification tier
    q75 = posts_clean["post_num_comments"].quantile(0.75)
    q90 = posts_clean["post_num_comments"].quantile(0.90)
    posts_clean["thread_tier"] = pd.cut(
        posts_clean["post_num_comments"],
        bins=[-1, 5, q75, q90, float("inf")],
        labels=["low", "medium", "high", "viral"],
    )

    n_after_p = len(posts_clean)
    report.append(f"\nPOSTS CLEANING")
    report.append(f"  Before   : {n_before_p:>8,}")
    report.append(f"  After    : {n_after_p:>8,}")
    report.append(f"  Removed  : {n_before_p - n_after_p:>8,}")

    # ── 4. Clean EDGES ────────────────────────────────────────────
    print("Cleaning edges...")
    n_before_e = len(edges)

    edges_clean = edges.copy()

    # Remove self-loops
    mask_self = edges_clean["source"] == edges_clean["target"]

    # Remove bot actors
    mask_bot_e = (
        edges_clean["source"].isin(BOTS) | edges_clean["target"].isin(BOTS)
    )

    # Remove unresolved targets
    mask_unknown = edges_clean["target"] == "unknown"

    edges_clean = edges_clean[~mask_self & ~mask_bot_e & ~mask_unknown]
    edges_clean = edges_clean.drop_duplicates()

    # Log-scaled weight
    edges_clean["weight_log"] = edges_clean["weight"].clip(lower=0).apply(
        lambda x: math.log(x + 1)
    )

    # Tie type per edge (high weight at depth 0 = weak tie reach)
    edges_clean["tie_type"] = edges_clean.apply(
        lambda r: "weak" if r["weight"] > median_proxy / (r["depth"] + 1) else "strong",
        axis=1,
    )

    n_after_e = len(edges_clean)
    report.append(f"\nEDGES CLEANING")
    report.append(f"  Before    : {n_before_e:>8,}")
    report.append(f"  After     : {n_after_e:>8,}")
    report.append(f"  Self-loops: {mask_self.sum():>8,}")
    report.append(f"  Bots      : {mask_bot_e.sum():>8,}")
    report.append(f"  Tie type dist: {edges_clean['tie_type'].value_counts().to_dict()}")

    # ── 5. Users (add computed fields) ───────────────────────────
    print("Processing users...")
    # is_bridge_user already set by scraper; add subreddit count label
    users["bridge_label"] = users["is_bridge_user"].map(
        {True: "Bridge user", False: "Single-community"}
    )
    report.append(f"\nUSERS")
    report.append(f"  Total        : {len(users):>8,}")
    report.append(f"  Bridge users : {users['is_bridge_user'].sum():>8,}  "
                  f"({users['is_bridge_user'].mean()*100:.1f}%)")

    # ── 6. Save cleaned files ─────────────────────────────────────
    if save:
        print(f"Saving cleaned files to {output_dir}/...")

        # Drop period column before saving (not serialisable)
        comments_save = comments_clean.copy()
        comments_save["year_month"] = comments_save["year_month"].astype(str)
        posts_save = posts_clean.copy()
        posts_save["year_month"] = posts_save["year_month"].astype(str)

        comments_save.to_csv(os.path.join(output_dir, "comments_clean.csv"), index=False)
        posts_save.to_csv(   os.path.join(output_dir, "posts_clean.csv"),    index=False)
        edges_clean.to_csv(  os.path.join(output_dir, "edges_clean.csv"),    index=False)
        users.to_csv(        os.path.join(output_dir, "users.csv"),           index=False)

        report_text = "\n".join(report)
        with open(os.path.join(output_dir, "pipeline_summary.txt"), "w") as f:
            f.write(report_text)

        print(report_text)

    return comments_clean, posts_clean, edges_clean, users


# ── Run as script ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    comments, posts, edges, users = load_and_clean(
        data_dir=DATA_DIR, output_dir=OUTPUT_DIR, save=True
    )
    print("\nDone. Cleaned files saved to:", OUTPUT_DIR)
    print(f"  comments_clean.csv : {len(comments):,} rows")
    print(f"  posts_clean.csv    : {len(posts):,} rows")
    print(f"  edges_clean.csv    : {len(edges):,} rows")
    print(f"  users.csv          : {len(users):,} rows")
