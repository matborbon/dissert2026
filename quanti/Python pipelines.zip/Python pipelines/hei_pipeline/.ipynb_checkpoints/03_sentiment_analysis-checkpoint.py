"""
hei_pipeline/03_sentiment_analysis.py
=======================================
Module 3 — RoBERTa Sentiment Analysis (RQ2)

Purpose
-------
Scores all cleaned comments using the Cardiff NLP twitter-roberta-base-
sentiment-latest model (Barbieri et al., 2020). Saves per-comment scores,
produces cross-analysis tables (sentiment × subreddit, sentiment × tie type),
and prepares the NVivo sampling export.

Why RoBERTa over VADER
-----------------------
  - Bidirectional attention captures sarcasm, negation, and context
  - Trained on 124M tweets — analogous register to Reddit posts
  - Outperforms VADER on informal, code-switched social media text
    (Bharadwaj et al., 2024; Memon et al., 2024)
  - Applied to HEI subreddit data in Yan & Liu (2021)

References
----------
  Barbieri et al. (2020). TweetEval. EMNLP Findings.
    https://doi.org/10.18653/v1/2020.findings-emnlp.148
  Liu et al. (2019). RoBERTa. arXiv:1907.11692.
  Bharadwaj et al. (2024). RoBERTa and VADER. Springer ICISD.
  Memon et al. (2024). Sarcasm via transformers. SES, 2(5).
  Yan & Liu (2021). COVID-19 Sentiment in College Subreddits. arXiv:2112.04351.

Input files  (from cleaned/)
------------------------------
  comments_clean.csv

Output files (to outputs/)
----------------------------
  comments_scored.csv      — full comments with RoBERTa scores
  sentiment_by_subreddit.csv
  sentiment_by_tietype.csv
  nvivo_sample_bert.csv    — stratified 500-comment NVivo export

Usage
-----
  python 03_sentiment_analysis.py

  Requires:
    pip install transformers torch scipy tqdm

  Runtime:
    ~5–10 min CPU  |  ~60 sec GPU  (30,229 comments, batch_size=32)
    Reduce batch_size to 16 if you get CUDA out-of-memory errors.
"""

import os
import numpy as np
import pandas as pd
from scipy.special import softmax
from scipy.stats import chi2_contingency, mannwhitneyu
from tqdm import tqdm

try:
    import torch
    from transformers import (
        AutoTokenizer,
        AutoConfig,
        AutoModelForSequenceClassification,
    )
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False
    print("WARNING: transformers/torch not installed. "
          "Run: pip install transformers torch")

CLEANED_DIR = "cleaned"
OUTPUT_DIR  = "outputs"
MODEL_NAME  = "cardiffnlp/twitter-roberta-base-sentiment-latest"
BATCH_SIZE  = 32
CONFIDENCE_THRESHOLD = 0.60   # below this = flag for manual NVivo review

# RoBERTa label mapping
LABELS = {0: "negative", 1: "neutral", 2: "positive"}


# ── Preprocessing ─────────────────────────────────────────────────────────────
def preprocess(text: str) -> str:
    """
    Cardiff NLP convention: replace Reddit usernames, subreddit mentions,
    and URLs with generic tokens to match Twitter-RoBERTa training format.
    """
    tokens = []
    for t in str(text).split():
        if t.startswith(("u/", "/u/")):
            tokens.append("@user")
        elif t.startswith(("r/", "/r/")):
            tokens.append("@user")
        elif t.startswith(("http", "www")):
            tokens.append("http")
        else:
            tokens.append(t)
    return " ".join(tokens)


# ── Batch inference ───────────────────────────────────────────────────────────
def score_batch(texts: list, tokenizer, model, device, batch_size=BATCH_SIZE) -> list:
    """
    Run RoBERTa sentiment inference over a list of texts.

    Returns list of dicts per text:
      roberta_label     : 'positive' | 'neutral' | 'negative'
      roberta_neg       : probability of negative class
      roberta_neu       : probability of neutral class
      roberta_pos       : probability of positive class
      roberta_compound  : score_pos - score_neg  → [-1, +1]
      roberta_confidence: max class probability  → reliability indicator
    """
    results = []
    for i in tqdm(range(0, len(texts), batch_size), desc="RoBERTa scoring"):
        batch = [preprocess(t) for t in texts[i : i + batch_size]]
        encoded = tokenizer(
            batch,
            padding=True,
            truncation=True,
            max_length=128,
            return_tensors="pt",
        ).to(device)
        with torch.no_grad():
            logits = model(**encoded).logits.cpu().numpy()
        probs = softmax(logits, axis=1)
        for p in probs:
            results.append({
                "roberta_label":      LABELS[int(np.argmax(p))],
                "roberta_neg":        float(p[0]),
                "roberta_neu":        float(p[1]),
                "roberta_pos":        float(p[2]),
                "roberta_compound":   float(p[2] - p[0]),
                "roberta_confidence": float(p.max()),
            })
    return results


# ── Cross-analysis tables ─────────────────────────────────────────────────────
def compute_cross_tables(df_scored: pd.DataFrame) -> dict:
    """
    Compute sentiment × subreddit and sentiment × tie type tables.
    Runs chi-square and Mann-Whitney U tests.
    Returns dict of DataFrames and statistics.
    """
    results = {}

    # Sentiment by subreddit
    sub_counts = (
        df_scored.groupby(["subreddit", "roberta_label"])
        .size()
        .unstack(fill_value=0)
    )
    sub_pct = sub_counts.div(sub_counts.sum(axis=1), axis=0) * 100
    results["sentiment_by_subreddit_counts"] = sub_counts
    results["sentiment_by_subreddit_pct"]    = sub_pct.round(1)

    # Sentiment by tie type
    tie_counts = (
        df_scored.groupby(["tie_type", "roberta_label"])
        .size()
        .unstack(fill_value=0)
    )
    tie_pct = tie_counts.div(tie_counts.sum(axis=1), axis=0) * 100
    results["sentiment_by_tietype_counts"] = tie_counts
    results["sentiment_by_tietype_pct"]    = tie_pct.round(1)

    # Chi-square: sentiment distribution differs by tie type?
    chi2_stat, p_chi, dof, _ = chi2_contingency(tie_counts)
    results["chi2_stat"] = chi2_stat
    results["chi2_p"]    = p_chi
    results["chi2_dof"]  = dof

    # Mann-Whitney U: compound score differs by tie type?
    weak_scores   = df_scored[df_scored["tie_type"]=="weak"]["roberta_compound"]
    strong_scores = df_scored[df_scored["tie_type"]=="strong"]["roberta_compound"]
    u_stat, p_mw = mannwhitneyu(weak_scores, strong_scores, alternative="two-sided")
    results["mw_u"]            = u_stat
    results["mw_p"]            = p_mw
    results["weak_mean_compound"]   = float(weak_scores.mean())
    results["strong_mean_compound"] = float(strong_scores.mean())

    return results


# ── NVivo stratified sample ────────────────────────────────────────────────────
def build_nvivo_sample(df_scored: pd.DataFrame, n_per_stratum=150) -> pd.DataFrame:
    """
    Build a stratified sample for NVivo qualitative coding:
      high_reach           — top n by comment_score (broad weak-tie reach)
      deep_thread          — top n by comment_depth (strong-tie exchanges)
      random               — random sample
      low_confidence_review— RoBERTa confidence < threshold (Taglish / ambiguous)
    """
    strata = [
        df_scored.nlargest(n_per_stratum, "comment_score").assign(
            sample_type="high_reach"
        ),
        df_scored[df_scored["comment_score"] > 0]
        .nlargest(n_per_stratum, "comment_depth")
        .assign(sample_type="deep_thread"),
        df_scored.sample(n_per_stratum, random_state=42).assign(
            sample_type="random"
        ),
        df_scored[~df_scored["roberta_reliable"]]
        .sample(
            min(n_per_stratum, (~df_scored["roberta_reliable"]).sum()),
            random_state=42,
        )
        .assign(sample_type="low_confidence_review"),
    ]
    sample = pd.concat(strata).drop_duplicates(subset=["comment_id"])

    keep_cols = [
        "subreddit", "post_title", "comment_id", "comment_body",
        "comment_author", "comment_score", "comment_depth",
        "comment_created_utc", "tie_type", "roberta_label",
        "roberta_compound", "roberta_confidence", "roberta_reliable",
        "sample_type",
    ]
    return sample[[c for c in keep_cols if c in sample.columns]]


# ── Main ──────────────────────────────────────────────────────────────────────
def run_sentiment():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Load comments
    print("Loading cleaned comments...")
    df = pd.read_csv(
        os.path.join(CLEANED_DIR, "comments_clean.csv"),
        parse_dates=["comment_created_utc"],
    )
    if "tie_type" not in df.columns:
        median_proxy = df["tie_strength_proxy"].median()
        df["tie_type"] = df["tie_strength_proxy"].apply(
            lambda x: "weak" if x > median_proxy else "strong"
        )

    # Load or compute RoBERTa scores
    scored_path = os.path.join(OUTPUT_DIR, "comments_scored.csv")
    if os.path.exists(scored_path):
        print(f"Found existing scores at {scored_path} — loading...")
        df_scored = pd.read_csv(scored_path, parse_dates=["comment_created_utc"])
    else:
        if not TRANSFORMERS_AVAILABLE:
            raise RuntimeError(
                "transformers/torch not installed. "
                "Run: pip install transformers torch"
            )

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {device}")
        print(f"Loading model: {MODEL_NAME}")
        print("  First run downloads ~500MB and caches locally.")

        tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
        model = AutoModelForSequenceClassification.from_pretrained(MODEL_NAME).to(device)
        model.eval()

        print(f"Scoring {len(df):,} comments (batch_size={BATCH_SIZE})...")
        scores = score_batch(df["comment_body"].tolist(), tokenizer, model, device)
        scores_df = pd.DataFrame(scores, index=df.index)
        df_scored = pd.concat([df, scores_df], axis=1)
        df_scored["roberta_reliable"] = (
            df_scored["roberta_confidence"] >= CONFIDENCE_THRESHOLD
        )
        df_scored.to_csv(scored_path, index=False)
        print(f"  Scores saved to {scored_path}")

    # Ensure reliable flag
    if "roberta_reliable" not in df_scored.columns:
        df_scored["roberta_reliable"] = (
            df_scored["roberta_confidence"] >= CONFIDENCE_THRESHOLD
        )

    # Print distribution
    print("\nSentiment distribution:")
    print(df_scored["roberta_label"].value_counts().to_string())
    print(f"Mean compound  : {df_scored['roberta_compound'].mean():+.4f}")
    print(f"Mean confidence: {df_scored['roberta_confidence'].mean():.3f}")
    print(f"High-conf (>= {CONFIDENCE_THRESHOLD}): "
          f"{df_scored['roberta_reliable'].mean()*100:.1f}%")

    # Cross-analysis
    print("\nComputing cross-analysis tables...")
    cross = compute_cross_tables(df_scored)

    print("\nSentiment % by subreddit:")
    print(cross["sentiment_by_subreddit_pct"].to_string())
    print("\nSentiment % by tie type:")
    print(cross["sentiment_by_tietype_pct"].to_string())
    print(f"\nChi-square (sentiment × tie type):")
    print(f"  χ²({cross['chi2_dof']}) = {cross['chi2_stat']:.2f}, "
          f"p = {cross['chi2_p']:.6f}")
    print(f"Mann-Whitney U (compound, weak vs strong):")
    print(f"  Weak mean   = {cross['weak_mean_compound']:+.4f}")
    print(f"  Strong mean = {cross['strong_mean_compound']:+.4f}")
    print(f"  U = {cross['mw_u']:.0f}, p = {cross['mw_p']:.6f}")

    # Save cross tables
    cross["sentiment_by_subreddit_pct"].to_csv(
        os.path.join(OUTPUT_DIR, "sentiment_by_subreddit.csv")
    )
    cross["sentiment_by_tietype_pct"].to_csv(
        os.path.join(OUTPUT_DIR, "sentiment_by_tietype.csv")
    )

    # NVivo sample
    nvivo = build_nvivo_sample(df_scored)
    nvivo.to_csv(os.path.join(OUTPUT_DIR, "nvivo_sample_bert.csv"), index=False)
    print(f"\nNVivo sample: {len(nvivo):,} comments")
    print(nvivo["sample_type"].value_counts().to_string())

    print(f"\nAll sentiment outputs saved to {OUTPUT_DIR}/")
    return df_scored, cross


if __name__ == "__main__":
    df_scored, cross = run_sentiment()
