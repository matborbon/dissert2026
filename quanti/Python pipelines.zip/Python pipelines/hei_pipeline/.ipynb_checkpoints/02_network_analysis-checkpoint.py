"""
hei_pipeline/02_network_analysis.py
=====================================
Module 2 — Social Network Analysis (RQ1 & Granovetter Weak Ties)

Purpose
-------
Builds the directed weighted interaction graph from cleaned edges,
computes all network metrics (centrality, clustering, components),
operationalizes Granovetter's weak ties, identifies bridge users,
and exports enriched node/edge files for visualization.

Input files  (from cleaned/)
------------------------------
  edges_clean.csv
  users.csv
  comments_clean.csv    — for upvote and interaction aggregates

Output files (to outputs/)
----------------------------
  gephi_nodes_enriched.csv  — 10,801 nodes with 36 metric columns
  gephi_edges_enriched.csv  — 21,530 edges with tie_type, weight_log
  network_metrics.csv       — per-HEI and merged summary table
  per_hei_nodes/            — per-HEI node files (4 files)
  per_hei_edges/            — per-HEI edge files (4 files)

Usage
-----
  python 02_network_analysis.py
"""

import os
import math
import pandas as pd
import numpy as np
import networkx as nx
from datetime import datetime

# ── Configuration ─────────────────────────────────────────────────────────────
CLEANED_DIR = "cleaned"
OUTPUT_DIR  = "outputs"
SUBREDDITS  = ["Benilde", "dlsu", "peyups", "AdMU"]

# Betweenness approximation — use k=None for exact (15-20 min on full graph)
# k=500 is sufficient for comparative analysis and takes ~2 min
BETWEENNESS_K = 500


def build_graph(edges_df):
    """Build a directed weighted NetworkX DiGraph from an edges DataFrame."""
    G = nx.from_pandas_edgelist(
        edges_df,
        source="source",
        target="target",
        edge_attr="weight",
        create_using=nx.DiGraph(),
    )
    return G


def compute_metrics(G, k=BETWEENNESS_K):
    """
    Compute all centrality and structural metrics for a graph.
    Returns a dict of metric name -> value or node->value dict.
    """
    print(f"    Nodes: {G.number_of_nodes():,}  Edges: {G.number_of_edges():,}")
    G_und = G.to_undirected()

    degree_cent      = nx.degree_centrality(G)
    in_degree_cent   = nx.in_degree_centrality(G)
    out_degree_cent  = nx.out_degree_centrality(G)
    in_degree_raw    = dict(G.in_degree())
    out_degree_raw   = dict(G.out_degree())
    in_degree_w      = dict(G.in_degree(weight="weight"))
    out_degree_w     = dict(G.out_degree(weight="weight"))
    clustering       = nx.clustering(G_und)
    wcc              = list(nx.weakly_connected_components(G))

    print(f"    Computing betweenness (k={k})...")
    betweenness = nx.betweenness_centrality(
        G, weight="weight", normalized=True, k=min(k, G.number_of_nodes())
    )

    density       = nx.density(G)
    avg_clust     = nx.average_clustering(G_und)
    n_components  = len(wcc)
    largest_cc    = max(len(c) for c in wcc)

    return {
        "degree_centrality":      degree_cent,
        "in_degree_centrality":   in_degree_cent,
        "out_degree_centrality":  out_degree_cent,
        "in_degree_raw":          in_degree_raw,
        "out_degree_raw":         out_degree_raw,
        "in_degree_weighted":     in_degree_w,
        "out_degree_weighted":    out_degree_w,
        "betweenness_centrality": betweenness,
        "clustering_coefficient": clustering,
        "density":                density,
        "avg_clustering":         avg_clust,
        "n_components":           n_components,
        "largest_cc_nodes":       largest_cc,
    }


def build_node_df(G, metrics, users_df, comments_df):
    """
    Assemble the enriched node DataFrame by merging centrality metrics,
    interaction statistics, and bridge user information.
    """
    nodes = list(G.nodes())

    # Centrality columns (node-level)
    node_df = pd.DataFrame({
        "user":               nodes,
        "degree_centrality":  [metrics["degree_centrality"].get(n, 0)     for n in nodes],
        "in_degree_centrality": [metrics["in_degree_centrality"].get(n, 0) for n in nodes],
        "out_degree_centrality":[metrics["out_degree_centrality"].get(n,0) for n in nodes],
        "in_degree_raw":      [metrics["in_degree_raw"].get(n, 0)         for n in nodes],
        "out_degree_raw":     [metrics["out_degree_raw"].get(n, 0)        for n in nodes],
        "in_degree_weighted": [metrics["in_degree_weighted"].get(n, 0)    for n in nodes],
        "out_degree_weighted":[metrics["out_degree_weighted"].get(n, 0)   for n in nodes],
        "betweenness_centrality":[metrics["betweenness_centrality"].get(n,0) for n in nodes],
        "clustering_coefficient":[metrics["clustering_coefficient"].get(n,0) for n in nodes],
    })

    # Interaction metrics per user (from comments)
    median_proxy = comments_df["tie_strength_proxy"].median()
    upvote_stats = (
        comments_df.groupby("comment_author").agg(
            total_upvotes_received=("comment_score", "sum"),
            mean_upvotes_received=("comment_score", "mean"),
            max_upvotes_received=("comment_score", "max"),
            total_comments=("comment_id", "count"),
            mean_depth=("comment_depth", "mean"),
            max_depth=("comment_depth", "max"),
            weak_tie_count=("tie_type", lambda x: (x == "weak").sum()),
            strong_tie_count=("tie_type", lambda x: (x == "strong").sum()),
            mean_tie_strength_proxy=("tie_strength_proxy", "mean"),
        )
        .reset_index()
        .rename(columns={"comment_author": "user"})
    )
    upvote_stats["weak_tie_ratio"] = (
        upvote_stats["weak_tie_count"] /
        (upvote_stats["weak_tie_count"] + upvote_stats["strong_tie_count"] + 1e-9)
    ).round(4)

    # Primary subreddit per user
    user_sub = (
        comments_df.groupby("comment_author")["subreddit"]
        .agg(lambda x: x.mode()[0])
        .reset_index()
        .rename(columns={"comment_author": "user", "subreddit": "primary_subreddit"})
    )

    # Merge everything
    node_df = (
        node_df
        .merge(upvote_stats, on="user", how="left")
        .merge(users_df[["user", "is_bridge_user", "num_subreddits"]], on="user", how="left")
        .merge(user_sub, on="user", how="left")
    )

    # Fill nulls for users who only appear as edge targets
    fill_zero = [
        "total_upvotes_received", "mean_upvotes_received", "max_upvotes_received",
        "total_comments", "mean_depth", "max_depth", "weak_tie_count",
        "strong_tie_count", "mean_tie_strength_proxy", "weak_tie_ratio",
    ]
    for col in fill_zero:
        node_df[col] = node_df[col].fillna(0)

    node_df["is_bridge_user"]   = node_df["is_bridge_user"].fillna(False)
    node_df["num_subreddits"]   = node_df["num_subreddits"].fillna(1).astype(int)
    node_df["primary_subreddit"]= node_df["primary_subreddit"].fillna("unknown")

    # Gephi size columns: pre-normalized to 1–100 range
    b_max = node_df["betweenness_centrality"].max()
    d_max = node_df["degree_centrality"].max()
    node_df["size_betweenness"] = (
        (node_df["betweenness_centrality"] / b_max * 99) + 1
    ).round(2).fillna(1)
    node_df["size_degree"] = (
        (node_df["degree_centrality"] / d_max * 99) + 1
    ).round(2).fillna(1)

    # Gephi Id and Label
    node_df = node_df.rename(columns={"user": "Id"})
    node_df["Label"] = node_df["Id"]

    # Round all floats
    float_cols = node_df.select_dtypes("float64").columns
    node_df[float_cols] = node_df[float_cols].round(6)

    return node_df


def run_analysis():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(os.path.join(OUTPUT_DIR, "per_hei_nodes"), exist_ok=True)
    os.makedirs(os.path.join(OUTPUT_DIR, "per_hei_edges"), exist_ok=True)

    # ── Load cleaned data ──────────────────────────────────────────
    print("Loading cleaned data...")
    edges_clean   = pd.read_csv(os.path.join(CLEANED_DIR, "edges_clean.csv"),
                                parse_dates=["timestamp"])
    users_df      = pd.read_csv(os.path.join(CLEANED_DIR, "users.csv"))
    comments_clean= pd.read_csv(os.path.join(CLEANED_DIR, "comments_clean.csv"),
                                parse_dates=["comment_created_utc"])
    posts_clean   = pd.read_csv(os.path.join(CLEANED_DIR, "posts_clean.csv"),
                                parse_dates=["post_created_utc"])

    # Ensure tie_type is present (in case comments were loaded without it)
    if "tie_type" not in comments_clean.columns:
        median_proxy = comments_clean["tie_strength_proxy"].median()
        comments_clean["tie_type"] = comments_clean["tie_strength_proxy"].apply(
            lambda x: "weak" if x > median_proxy else "strong"
        )

    summary_rows = []

    # ══════════════════════════════════════════════════════════════
    # MERGED CROSS-INSTITUTIONAL NETWORK
    # ══════════════════════════════════════════════════════════════
    print("\n== Merged cross-institutional network ==")
    G_merged = build_graph(edges_clean)
    metrics_merged = compute_metrics(G_merged, k=BETWEENNESS_K)

    # Build enriched node table
    gephi_nodes = build_node_df(G_merged, metrics_merged, users_df, comments_clean)

    # Enriched edges
    gephi_edges = edges_clean.copy()
    gephi_edges.columns = [c.title().replace("_", "") if c not in
                            ["source","target","weight","edge_type","subreddit","depth","timestamp","tie_type","weight_log"]
                            else c for c in gephi_edges.columns]
    gephi_edges = edges_clean.rename(columns={
        "source":"Source","target":"Target","weight":"Weight",
        "edge_type":"EdgeType","subreddit":"Subreddit","depth":"Depth",
        "timestamp":"Timestamp","tie_type":"TieType","weight_log":"WeightLog",
    })

    gephi_nodes.to_csv(os.path.join(OUTPUT_DIR, "gephi_nodes_enriched.csv"), index=False)
    gephi_edges.to_csv(os.path.join(OUTPUT_DIR, "gephi_edges_enriched.csv"), index=False)

    wcc_merged = list(nx.weakly_connected_components(G_merged))
    summary_rows.append({
        "Subreddit":       "MERGED",
        "Nodes":           G_merged.number_of_nodes(),
        "Edges":           G_merged.number_of_edges(),
        "Density":         round(metrics_merged["density"], 6),
        "Avg_Clustering":  round(metrics_merged["avg_clustering"], 4),
        "Components":      metrics_merged["n_components"],
        "Largest_CC_pct":  round(metrics_merged["largest_cc_nodes"] /
                                G_merged.number_of_nodes() * 100, 1),
        "Bridge_Users":    int(users_df["is_bridge_user"].sum()),
    })

    # ══════════════════════════════════════════════════════════════
    # PER-HEI NETWORKS
    # ══════════════════════════════════════════════════════════════
    for sub in SUBREDDITS:
        print(f"\n== Per-HEI: r/{sub} ==")
        e_sub = edges_clean[edges_clean["subreddit"] == sub].copy()
        c_sub = comments_clean[comments_clean["subreddit"] == sub].copy()

        G_sub = build_graph(e_sub)
        metrics_sub = compute_metrics(G_sub, k=min(300, G_sub.number_of_nodes()))
        node_df_sub = build_node_df(G_sub, metrics_sub, users_df, c_sub)
        node_df_sub["subreddit"] = sub

        edge_df_sub = e_sub.copy()

        node_df_sub.to_csv(
            os.path.join(OUTPUT_DIR, "per_hei_nodes", f"gephi_{sub}_nodes.csv"),
            index=False,
        )
        edge_df_sub.to_csv(
            os.path.join(OUTPUT_DIR, "per_hei_edges", f"gephi_{sub}_edges.csv"),
            index=False,
        )

        wcc_sub = list(nx.weakly_connected_components(G_sub))
        summary_rows.append({
            "Subreddit":       f"r/{sub}",
            "Nodes":           G_sub.number_of_nodes(),
            "Edges":           G_sub.number_of_edges(),
            "Density":         round(metrics_sub["density"], 6),
            "Avg_Clustering":  round(metrics_sub["avg_clustering"], 4),
            "Components":      metrics_sub["n_components"],
            "Largest_CC_pct":  round(metrics_sub["largest_cc_nodes"] /
                                    G_sub.number_of_nodes() * 100, 1),
            "Bridge_Users":    int(node_df_sub["is_bridge_user"].sum()),
        })

    # Save summary
    summary_df = pd.DataFrame(summary_rows)
    summary_df.to_csv(os.path.join(OUTPUT_DIR, "network_metrics.csv"), index=False)

    print("\nNetwork metrics summary:")
    print(summary_df.to_string(index=False))
    print(f"\nOutputs saved to {OUTPUT_DIR}/")
    return gephi_nodes, gephi_edges, summary_df


if __name__ == "__main__":
    gephi_nodes, gephi_edges, summary = run_analysis()
