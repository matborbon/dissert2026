"""
hei_pipeline/04_generate_figures.py
=====================================
Module 4 — Generate All Figures (Figs 4.1–4.7 and individual panels)

Purpose
-------
Generates all dissertation figures from cleaned data and scored comments.
Produces both composite figures (multi-panel) and individual panel PNGs
for direct insertion into the Word document.

Figures produced
-----------------
  fig1_network_map.png           — Network visualization (top-400 nodes)
  fig2_centrality.png            — 4-panel centrality composite
  fig3_per_hei.png               — 6-panel per-HEI comparison
  fig4_granovetter.png           — 4-panel Granovetter finding
  fig5_sentiment.png             — 4-panel sentiment analysis
  fig6_temporal.png              — 5-panel temporal dynamics
  fig7_amplification.png         — 6-panel amplification metrics

  Individual panels:
    fig2a_betweenness_hist.png   fig2b_degree_hist.png
    fig2c_bridge_violin.png      fig2d_indegree_subreddit.png
    fig3a_nodes.png ... fig3f_components.png
    fig4a_tie_type_donut.png ... fig4d_bridge_centrality.png
    fig5a_overall_sentiment.png ... fig5d_compound_boxplot.png
    fig6a_volume_over_time.png ... fig6e_edge_type.png
    fig7a_upvote_dist.png ... fig7f_clustering.png

Input files  (from outputs/ and cleaned/)
------------------------------------------
  gephi_nodes_enriched.csv
  gephi_edges_enriched.csv
  comments_clean.csv  (or comments_scored.csv if sentiment run)
  posts_clean.csv
  network_metrics.csv

Usage
-----
  python 04_generate_figures.py

  Requires:
    pip install matplotlib seaborn networkx scipy
"""

import os
import math
import numpy as np
import pandas as pd
import networkx as nx
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.patheffects as pe
import matplotlib.ticker as mticker
import seaborn as sns
from matplotlib.gridspec import GridSpec
import warnings

warnings.filterwarnings("ignore")

# ── Configuration ─────────────────────────────────────────────────────────────
CLEANED_DIR = "cleaned"
OUTPUT_DIR  = "outputs"
FIG_DIR     = "figures"         # all figures saved here
DPI         = 180

# Color palette — consistent across all figures
BG  = "#FFFFFF"
SF  = "#F8F9FA"
TX  = "#212529"
MU  = "#6C757D"
GR  = "#DEE2E6"

SUB_COLORS = {
    "Benilde": "#0d6efd",
    "dlsu":    "#198754",
    "peyups":  "#dc3545",
    "AdMU":    "#fd7e14",
    "unknown": "#adb5bd",
}
SENT_COLORS = {
    "positive": "#198754",
    "neutral":  "#6C757D",
    "negative": "#dc3545",
}

SAVE_KWARGS = dict(dpi=DPI, bbox_inches="tight", facecolor=BG, edgecolor="none")


# ── Matplotlib global style ───────────────────────────────────────────────────
def set_style():
    plt.rcParams.update({
        "figure.facecolor": BG,
        "axes.facecolor":   SF,
        "axes.edgecolor":   GR,
        "text.color":       TX,
        "axes.labelcolor":  TX,
        "xtick.color":      MU,
        "ytick.color":      MU,
        "grid.color":       GR,
        "grid.linewidth":   0.6,
        "font.family":      "DejaVu Sans",
        "axes.spines.top":  False,
        "axes.spines.right":False,
    })


# ── Data loaders ──────────────────────────────────────────────────────────────
def load_data():
    """Load all required DataFrames."""
    nodes = pd.read_csv(os.path.join(OUTPUT_DIR, "gephi_nodes_enriched.csv"))
    edges = pd.read_csv(os.path.join(OUTPUT_DIR, "gephi_edges_enriched.csv"))

    # Use scored comments if available, else fall back to clean
    scored_path = os.path.join(OUTPUT_DIR, "comments_scored.csv")
    clean_path  = os.path.join(CLEANED_DIR, "comments_clean.csv")
    if os.path.exists(scored_path):
        comments = pd.read_csv(scored_path, parse_dates=["comment_created_utc"])
    else:
        comments = pd.read_csv(clean_path,  parse_dates=["comment_created_utc"])

    if "tie_type" not in comments.columns:
        median_proxy = comments["tie_strength_proxy"].median()
        comments["tie_type"] = comments["tie_strength_proxy"].apply(
            lambda x: "weak" if x > median_proxy else "strong"
        )
    if "year_month" not in comments.columns:
        comments["year_month"] = comments["comment_created_utc"].dt.to_period("M")

    posts = pd.read_csv(os.path.join(CLEANED_DIR, "posts_clean.csv"),
                        parse_dates=["post_created_utc"])

    return nodes, edges, comments, posts


def save(path):
    plt.savefig(path, **SAVE_KWARGS)
    plt.close()
    print(f"  Saved: {os.path.basename(path)}")


# ══════════════════════════════════════════════════════════════════════════════
# FIG 1 — NETWORK MAP
# ══════════════════════════════════════════════════════════════════════════════
def fig1_network_map(nodes, edges):
    print("Generating Fig 1: Network Map...")
    fig, ax = plt.subplots(figsize=(14, 10))
    fig.patch.set_facecolor(BG); ax.set_facecolor(BG)

    top_n   = nodes.nlargest(400, "betweenness_centrality")
    top_ids = set(top_n["Id"])
    e_sub   = edges[(edges["Source"].isin(top_ids)) & (edges["Target"].isin(top_ids))].copy()

    G = nx.from_pandas_edgelist(
        e_sub, source="Source", target="Target",
        edge_attr="Weight", create_using=nx.DiGraph()
    )
    np.random.seed(42)
    pos = nx.spring_layout(G, k=2.8, seed=42, iterations=120)

    # Edges
    for _, r in e_sub.iterrows():
        if r["Source"] in pos and r["Target"] in pos:
            x0, y0 = pos[r["Source"]]; x1, y1 = pos[r["Target"]]
            col = "#fd7e1430" if r["TieType"] == "weak" else "#0d6efd25"
            lw  = min(1.5, max(0.15, r["Weight"] / 70))
            ax.plot([x0, x1], [y0, y1], "-", color=col, lw=lw, zorder=1,
                    solid_capstyle="round")

    # Nodes
    ninfo = {row["Id"]: row for _, row in top_n.iterrows()}
    for node in G.nodes():
        if node not in pos: continue
        row = ninfo.get(node)
        if row is None: continue
        x, y  = pos[node]
        color = SUB_COLORS.get(str(row["primary_subreddit"]), "#adb5bd")
        size  = 18 + (float(row["betweenness_centrality"]) / 0.001) ** 0.4 * 260
        ax.scatter(x, y, s=size, c=color, zorder=3, alpha=0.88, linewidths=0)
        if row["is_bridge_user"]:
            ax.scatter(x, y, s=size + 100, c="none",
                       edgecolors="#DAA520", linewidths=2, zorder=4)

    # Labels for top-12
    for _, row in nodes.nlargest(12, "betweenness_centrality").iterrows():
        if row["Id"] in pos:
            x, y = pos[row["Id"]]
            ax.annotate(row["Id"][:18], (x, y), xytext=(5, 5),
                textcoords="offset points", fontsize=6.5, color="#212529",
                fontweight="bold", zorder=5,
                path_effects=[pe.withStroke(linewidth=2, foreground="white")])

    ax.set_xlim(-1.3, 1.3); ax.set_ylim(-1.3, 1.3); ax.axis("off")
    ax.text(0.5, 1.03,
        "Figure 4.1: Cross-Institutional HEI Subreddit Interaction Network",
        transform=ax.transAxes, ha="center", fontsize=13, fontweight="bold", color=TX)
    ax.text(0.5, 0.995,
        "Top-400 nodes by betweenness · Node size = betweenness centrality · "
        "Gold ring = bridge user",
        transform=ax.transAxes, ha="center", fontsize=8, color=MU)

    handles = [mpatches.Patch(color=v, label=f"r/{k}")
               for k, v in SUB_COLORS.items() if k != "unknown"]
    handles += [
        mpatches.Patch(facecolor="none", edgecolor="#DAA520", linewidth=2,
                       label="Bridge user"),
        mpatches.Patch(color="#fd7e14", alpha=0.6, label="Weak tie edge"),
        mpatches.Patch(color="#0d6efd", alpha=0.6, label="Strong tie edge"),
    ]
    ax.legend(handles=handles, loc="lower right", framealpha=0.9,
              facecolor="white", edgecolor=GR, labelcolor=TX, fontsize=8)

    ax.text(0.02, 0.98,
        "Nodes: 10,801  |  Edges: 21,530\n"
        "Density: 0.000185  |  Clustering: 0.0764\n"
        "Components: 113  |  Largest CC: 97.5%",
        transform=ax.transAxes, va="top", ha="left",
        fontsize=7.5, color=TX, linespacing=1.7,
        bbox=dict(boxstyle="round,pad=0.5", facecolor="white", edgecolor=GR, alpha=0.95))

    plt.tight_layout(pad=1.2)
    save(os.path.join(FIG_DIR, "fig1_network_map.png"))


# ══════════════════════════════════════════════════════════════════════════════
# FIG 2 — CENTRALITY (composite + 4 individual panels)
# ══════════════════════════════════════════════════════════════════════════════
def fig2_centrality(nodes):
    print("Generating Fig 2: Centrality...")
    subs = ["Benilde", "dlsu", "peyups", "AdMU"]
    cols = [SUB_COLORS[s] for s in subs]
    xl   = [f"r/{s}" for s in subs]
    bv   = nodes["betweenness_centrality"][nodes["betweenness_centrality"] > 0]
    dv   = nodes["degree_centrality"]
    bb   = nodes[nodes["is_bridge_user"] == True]["betweenness_centrality"].clip(upper=0.05)
    nb   = nodes[nodes["is_bridge_user"] == False]["betweenness_centrality"].clip(upper=0.05)
    means4 = [nodes[nodes["primary_subreddit"] == s]["in_degree_weighted"].clip(0, 200).mean() for s in subs]
    meds4  = [nodes[nodes["primary_subreddit"] == s]["in_degree_weighted"].clip(0, 200).median() for s in subs]

    def _2a(ax):
        ax.hist(bv, bins=60, color="#0d6efd", alpha=0.82, edgecolor="white", lw=0.3)
        ax.set_yscale("log")
        ax.axvline(bv.mean(), color="#fd7e14", lw=2, ls="--",
                   label=f"Mean = {bv.mean():.5f}")
        ax.set_title("Betweenness Centrality Distribution", fontsize=11,
                     fontweight="bold", color=TX, pad=8)
        ax.set_xlabel("Betweenness centrality", fontsize=9, color=MU)
        ax.set_ylabel("Node count (log scale)", fontsize=9, color=MU)
        ax.legend(fontsize=8, facecolor="white", edgecolor=GR)
        ax.text(0.97, 0.95, f"n = {len(bv):,} nodes > 0\nMax = {bv.max():.4f}",
                transform=ax.transAxes, ha="right", va="top", fontsize=7.5, color=MU)

    def _2b(ax):
        ax.hist(dv, bins=60, color="#198754", alpha=0.82, edgecolor="white", lw=0.3)
        ax.set_yscale("log")
        ax.axvline(dv.mean(), color="#fd7e14", lw=2, ls="--",
                   label=f"Mean = {dv.mean():.5f}")
        ax.set_title("Degree Centrality Distribution", fontsize=11,
                     fontweight="bold", color=TX, pad=8)
        ax.set_xlabel("Degree centrality", fontsize=9, color=MU)
        ax.set_ylabel("Node count (log scale)", fontsize=9, color=MU)
        ax.legend(fontsize=8, facecolor="white", edgecolor=GR)

    def _2c(ax):
        pts = ax.violinplot([nb, bb], showmedians=True, showextrema=True)
        for i, pc in enumerate(pts["bodies"]):
            pc.set_facecolor(["#0d6efd", "#fd7e14"][i])
            pc.set_alpha(0.72); pc.set_edgecolor(GR)
        pts["cmedians"].set_color(TX)
        pts["cmins"].set_color(MU); pts["cmaxes"].set_color(MU); pts["cbars"].set_color(MU)
        ax.set_xticks([1, 2])
        ax.set_xticklabels(["Non-bridge\n(n=11,115)", "Bridge user\n(n=367)"],
                           fontsize=10, color=TX)
        ax.set_title("Betweenness: Bridge vs Non-Bridge Users",
                     fontsize=11, fontweight="bold", color=TX, pad=8)
        ax.set_ylabel("Betweenness centrality (clipped ≤ 0.05)", fontsize=9, color=MU)
        ax.text(0.5, 0.97, "*** p < .001  (Mann-Whitney U)",
                transform=ax.transAxes, ha="center", va="top",
                fontsize=10, color="#198754", fontweight="bold")
        for i, (val, lbl, col) in enumerate([
            (nb.mean(), "Mean: 0.000668", "#0d6efd"),
            (bb.mean(), "Mean: 0.004062", "#fd7e14"),
        ]):
            ax.annotate(lbl, (i + 1, val), xytext=(26, 0),
                        textcoords="offset points", fontsize=9,
                        color=col, ha="left", va="center", fontweight="bold")

    def _2d(ax):
        x4 = np.arange(4); w = 0.35
        b1 = ax.bar(x4 - w/2, means4, w, color=cols, alpha=0.85, label="Mean",
                    edgecolor="white")
        ax.bar(x4 + w/2, meds4, w, color=cols, alpha=0.4, label="Median",
               edgecolor=cols, linewidth=1.2)
        ax.set_xticks(x4); ax.set_xticklabels(xl, fontsize=10, color=TX)
        ax.set_title("Weighted In-Degree by Subreddit",
                     fontsize=11, fontweight="bold", color=TX, pad=8)
        ax.set_ylabel("Weighted in-degree (replies received)", fontsize=9, color=MU)
        ax.legend(fontsize=8, facecolor="white", edgecolor=GR)
        for bar in b1:
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.3,
                    f"{bar.get_height():.1f}", ha="center", va="bottom",
                    fontsize=8, color=TX)

    # Composite
    fig = plt.figure(figsize=(14, 10)); fig.patch.set_facecolor(BG)
    gs  = GridSpec(2, 2, hspace=0.44, wspace=0.32)
    axs = [fig.add_subplot(gs[i // 2, i % 2]) for i in range(4)]
    for ax in axs: ax.set_facecolor(SF)
    _2a(axs[0]); _2b(axs[1]); _2c(axs[2]); _2d(axs[3])
    fig.suptitle("Figure 4.2: Network Centrality Metrics — RQ1 Structural Analysis",
                 fontsize=13, fontweight="bold", color=TX, y=1.01)
    save(os.path.join(FIG_DIR, "fig2_centrality.png"))

    # Individual panels
    panels = [("fig2a_betweenness_hist.png", _2a, "Figure 4.2a: Betweenness Centrality Distribution"),
              ("fig2b_degree_hist.png",      _2b, "Figure 4.2b: Degree Centrality Distribution"),
              ("fig2c_bridge_violin.png",    _2c, "Figure 4.2c: Betweenness — Bridge vs Non-Bridge"),
              ("fig2d_indegree_subreddit.png",_2d,"Figure 4.2d: Weighted In-Degree by Subreddit")]
    for fname, draw_fn, title in panels:
        fig, ax = plt.subplots(figsize=(8, 5)); fig.patch.set_facecolor(BG); ax.set_facecolor(SF)
        draw_fn(ax)
        ax.set_title(title, fontsize=12, fontweight="bold", color=TX, pad=10)
        plt.tight_layout()
        save(os.path.join(FIG_DIR, fname))


# ══════════════════════════════════════════════════════════════════════════════
# FIG 3 — PER-HEI (composite + 6 individual panels)
# ══════════════════════════════════════════════════════════════════════════════
def fig3_per_hei():
    print("Generating Fig 3: Per-HEI comparison...")
    PHD = {
        "Benilde": {"nodes":1717,"edges":3180,"density":0.001079,"clustering":0.0528,"components":30,"lcc":95.9,"bridge":88},
        "dlsu":    {"nodes":2250,"edges":4006,"density":0.000792,"clustering":0.0550,"components":27,"lcc":97.4,"bridge":216},
        "peyups":  {"nodes":3958,"edges":6653,"density":0.000425,"clustering":0.0466,"components":53,"lcc":96.5,"bridge":175},
        "AdMU":    {"nodes":3229,"edges":7692,"density":0.000738,"clustering":0.1449,"components":17,"lcc":98.2,"bridge":241},
    }
    subs = list(PHD.keys())
    cols = [SUB_COLORS[s] for s in subs]
    xl   = [f"r/{s}" for s in subs]

    def lbar(ax, vals, title, ylabel, fmt="{:.0f}", ylpad=None):
        bars = ax.bar(xl, vals, color=cols, alpha=0.85, edgecolor="white", lw=0.5)
        ax.set_title(title, fontsize=10, fontweight="bold", color=TX, pad=8)
        ax.set_ylabel(ylabel, fontsize=9, color=MU)
        pad = ylpad if ylpad else max(vals) * 0.015
        for bar, v in zip(bars, vals):
            ax.text(bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + pad, fmt.format(v),
                    ha="center", va="bottom", fontsize=8, color=TX)
        return bars

    panel_specs = [
        ("fig3a_nodes.png",      [PHD[s]["nodes"]      for s in subs], "Figure 4.3a: Nodes (Users)",             "Count",     "{:,.0f}", 30),
        ("fig3b_edges.png",      [PHD[s]["edges"]      for s in subs], "Figure 4.3b: Edges (Interactions)",      "Count",     "{:,.0f}", 50),
        ("fig3c_density.png",    [PHD[s]["density"]    for s in subs], "Figure 4.3c: Network Density",           "Density",   "{:.6f}", 0.000025),
    ]

    # Composite
    fig = plt.figure(figsize=(14, 9)); fig.patch.set_facecolor(BG)
    gs  = GridSpec(2, 3, hspace=0.5, wspace=0.36)
    axs = [fig.add_subplot(gs[i // 3, i % 3]) for i in range(6)]
    for ax in axs: ax.set_facecolor(SF)

    lbar(axs[0], [PHD[s]["nodes"]    for s in subs], "Nodes (Users)",         "Count",   "{:,.0f}", 30)
    lbar(axs[1], [PHD[s]["edges"]    for s in subs], "Edges (Interactions)",  "Count",   "{:,.0f}", 50)
    lbar(axs[2], [PHD[s]["density"]  for s in subs], "Network Density",       "Density", "{:.6f}",  0.000025)

    cv = [PHD[s]["clustering"] for s in subs]
    bars3 = axs[3].bar(xl, cv, color=cols, alpha=0.85, edgecolor="white", lw=0.5)
    bars3[3].set_edgecolor("#212529"); bars3[3].set_linewidth(2.5)
    axs[3].set_title("Clustering Coefficient", fontsize=10, fontweight="bold", color=TX, pad=8)
    axs[3].set_ylabel("Coefficient", fontsize=9, color=MU)
    axs[3].text(3, cv[3] + 0.006, "★  3× higher", ha="center",
                fontsize=10, color="#fd7e14", fontweight="bold")
    for i, v in enumerate(cv):
        axs[3].text(i, v + 0.001, f"{v}", ha="center", va="bottom", fontsize=8, color=TX)

    bv2 = [PHD[s]["bridge"] for s in subs]
    bp2 = [PHD[s]["bridge"] / PHD[s]["nodes"] * 100 for s in subs]
    axs[4].bar(xl, bv2, color=cols, alpha=0.85, edgecolor="white", lw=0.5)
    ax4b = axs[4].twinx()
    ax4b.plot(xl, bp2, "o--", color="#fd7e14", lw=2, ms=8, zorder=5)
    ax4b.set_ylabel("% of community", color="#fd7e14", fontsize=9)
    ax4b.tick_params(colors="#fd7e14")
    for sp in ["top","right","left","bottom"]: ax4b.spines[sp].set_color(GR)
    axs[4].set_title("Bridge Users (2+ HEIs)", fontsize=10, fontweight="bold", color=TX, pad=8)
    axs[4].set_ylabel("Count", fontsize=9, color=MU)
    for i, v in enumerate(bv2): axs[4].text(i, v + 2, str(v), ha="center", va="bottom", fontsize=8, color=TX)

    cpv = [PHD[s]["components"] for s in subs]
    lccv= [PHD[s]["lcc"]        for s in subs]
    axs[5].bar(xl, cpv, color=cols, alpha=0.85, edgecolor="white", lw=0.5)
    ax5b = axs[5].twinx()
    ax5b.plot(xl, lccv, "s--", color="#6f42c1", lw=2, ms=8)
    ax5b.set_ylabel("Largest CC %", color="#6f42c1", fontsize=9)
    ax5b.tick_params(colors="#6f42c1"); ax5b.set_ylim(90, 100)
    for sp in ["top","right","left","bottom"]: ax5b.spines[sp].set_color(GR)
    axs[5].set_title("Components & Connectivity", fontsize=10, fontweight="bold", color=TX, pad=8)
    axs[5].set_ylabel("Component count", fontsize=9, color=MU)
    for i, v in enumerate(cpv): axs[5].text(i, v + 0.3, str(v), ha="center", va="bottom", fontsize=8, color=TX)

    fig.suptitle("Figure 4.3: Per-HEI Intra-Community Network Analysis (RQ1)",
                 fontsize=13, fontweight="bold", color=TX, y=1.01)
    save(os.path.join(FIG_DIR, "fig3_per_hei.png"))

    # Individual panels (clustering + bridge + components as separate PNGs)
    for fname, vals, title, ylabel, fmt, ylpad in panel_specs:
        fig, ax = plt.subplots(figsize=(8, 5)); fig.patch.set_facecolor(BG); ax.set_facecolor(SF)
        lbar(ax, vals, title, ylabel, fmt, ylpad)
        plt.tight_layout(); save(os.path.join(FIG_DIR, fname))

    for fname, vals, title, star_idx, star_text in [
        ("fig3d_clustering.png", cv, "Figure 4.3d: Clustering Coefficient by Subreddit", 3, "★  3× higher"),
    ]:
        fig, ax = plt.subplots(figsize=(8, 5)); fig.patch.set_facecolor(BG); ax.set_facecolor(SF)
        bs = ax.bar(xl, vals, color=cols, alpha=0.85, edgecolor="white", lw=0.5)
        bs[star_idx].set_edgecolor("#212529"); bs[star_idx].set_linewidth(2.5)
        ax.set_title(title, fontsize=12, fontweight="bold", color=TX, pad=10)
        ax.text(star_idx, vals[star_idx] + 0.006, star_text, ha="center",
                fontsize=10, color="#fd7e14", fontweight="bold")
        for i, v in enumerate(vals): ax.text(i, v + 0.001, f"{v}", ha="center", va="bottom", fontsize=9, color=TX)
        plt.tight_layout(); save(os.path.join(FIG_DIR, fname))

    for fname, title, main_vals, line_vals, line_col, line_lbl, y2_lbl in [
        ("fig3e_bridge_users.png", "Figure 4.3e: Bridge Users (Active in 2+ HEIs)",
         bv2, bp2, "#fd7e14", "% of community", "% of community"),
        ("fig3f_components.png", "Figure 4.3f: Components & Largest Connected Component",
         cpv, lccv, "#6f42c1", "Largest CC %", "Largest CC %"),
    ]:
        fig, ax = plt.subplots(figsize=(8, 5)); fig.patch.set_facecolor(BG); ax.set_facecolor(SF)
        ax.bar(xl, main_vals, color=cols, alpha=0.85, edgecolor="white", lw=0.5)
        axb = ax.twinx()
        axb.plot(xl, line_vals, "o--", color=line_col, lw=2, ms=8, label=line_lbl)
        axb.set_ylabel(y2_lbl, color=line_col, fontsize=9); axb.tick_params(colors=line_col)
        if "CC" in y2_lbl: axb.set_ylim(90, 100)
        for sp in ["top","right","left","bottom"]: axb.spines[sp].set_color(GR)
        ax.set_title(title, fontsize=12, fontweight="bold", color=TX, pad=10)
        ax.set_ylabel("Count", fontsize=9, color=MU)
        for i, v in enumerate(main_vals): ax.text(i, v * 1.02, str(v) if isinstance(v,int) else f"{v:.0f}", ha="center", va="bottom", fontsize=9, color=TX)
        plt.tight_layout(); save(os.path.join(FIG_DIR, fname))


# ══════════════════════════════════════════════════════════════════════════════
# FIG 4 — GRANOVETTER (composite + 4 individual panels)
# ══════════════════════════════════════════════════════════════════════════════
def fig4_granovetter():
    print("Generating Fig 4: Granovetter...")

    def _4a(ax):
        wedges, txt, atxt = ax.pie(
            [13860, 16369],
            labels=["Weak tie\n13,860 (45.9%)", "Strong tie\n16,369 (54.1%)"],
            colors=["#fd7e14", "#0d6efd"], startangle=90, autopct="%1.1f%%",
            pctdistance=0.72, wedgeprops=dict(width=0.6, edgecolor="white", lw=2.5))
        for t in txt:  t.set_color(TX);  t.set_fontsize(9)
        for t in atxt: t.set_color("white"); t.set_fontsize(9); t.set_fontweight("bold")
        ax.text(0, 0, "30,229\ncomments", ha="center", va="center",
                fontsize=10, fontweight="bold", color=TX)

    def _4b(ax):
        data  = [[25.3, 58.9, 15.8], [19.9, 52.6, 27.5]]
        lbls  = ["Strong tie", "Weak tie"]
        c4b   = ["#198754", "#6C757D", "#dc3545"]
        for yi, row in enumerate(data):
            left = 0
            for col, pct in zip(c4b, row):
                ax.barh(yi, pct, left=left, color=col, height=0.55,
                        edgecolor="white", lw=0.5)
                if pct > 7:
                    ax.text(left + pct / 2, yi, f"{pct:.1f}%",
                            ha="center", va="center", fontsize=9,
                            color="white", fontweight="bold")
                left += pct
        ax.set_xlim(0, 100); ax.set_yticks([0, 1])
        ax.set_yticklabels(lbls, fontsize=10, color=TX)
        ax.set_xlabel("% of comments", fontsize=9, color=MU)
        ax.xaxis.set_major_formatter(mticker.PercentFormatter())
        ax.legend(handles=[mpatches.Patch(color=c, label=l)
                  for c, l in zip(c4b, ["Positive","Neutral","Negative"])],
                  fontsize=8, facecolor="white", edgecolor=GR)
        ax.text(0.5, 1.07, "χ²(2) = 631.78, p < .001 ***",
                transform=ax.transAxes, ha="center", fontsize=9,
                color="#198754", fontweight="bold")

    def _4c(ax):
        ax.bar(["Strong tie", "Weak tie"], [0.1048, -0.0420],
               color=["#0d6efd", "#fd7e14"], width=0.5, edgecolor="white",
               lw=1, alpha=0.88)
        ax.axhline(0, color=MU, lw=1, ls="--")
        ax.set_ylabel("Compound score (pos − neg)", fontsize=9, color=MU)
        for x_, v, col in zip([0,1],[0.1048,-0.0420],["#0d6efd","#fd7e14"]):
            sign = "+" if v >= 0 else ""
            ax.text(x_, v + (0.007 if v >= 0 else -0.013),
                    f"{sign}{v:.4f}", ha="center",
                    va="bottom" if v >= 0 else "top",
                    fontsize=13, fontweight="bold", color=col)
        ax.text(0.5, 0.05, "Mann-Whitney U: p < .001",
                transform=ax.transAxes, ha="center", fontsize=9, color=MU, style="italic")

    def _4d(ax):
        metrics = ["Betweenness\nCentrality", "Degree\nCentrality", "Weighted\nIn-Degree"]
        bvals   = [0.004062, 0.000969, 24.125]
        nvals   = [0.000668, 0.000348, 12.206]
        mults   = [6.1, 2.8, 2.0]
        x4 = np.arange(3); w = 0.3
        ax.bar(x4 - w/2, bvals, w, color="#fd7e14", alpha=0.88,
               label="Bridge users (n=367)", edgecolor="white")
        ax.bar(x4 + w/2, nvals, w, color="#0d6efd", alpha=0.88,
               label="Non-bridge users (n=11,115)", edgecolor="white")
        ax.set_xticks(x4); ax.set_xticklabels(metrics, fontsize=10, color=TX)
        ax.set_ylabel("Centrality value", fontsize=9, color=MU)
        ax.legend(fontsize=8, facecolor="white", edgecolor=GR)
        for i, (bv, nv, mu) in enumerate(zip(bvals, nvals, mults)):
            ax.annotate("", xy=(i - w/2, bv), xytext=(i + w/2, bv),
                        arrowprops=dict(arrowstyle="<->", color="#212529", lw=1.5))
            ax.text(i, bv + bv * 0.1, f"{mu:.1f}×", ha="center",
                    fontsize=12, color="#212529", fontweight="bold")
            ax.text(i - w/2, bv + bv * 0.02,
                    f"{bv:.4f}" if i < 2 else f"{bv:.2f}",
                    ha="center", va="bottom", fontsize=8, color="#fd7e14", fontweight="bold")
            ax.text(i + w/2, nv + nv * 0.02 + 0.00002,
                    f"{nv:.4f}" if i < 2 else f"{nv:.2f}",
                    ha="center", va="bottom", fontsize=8, color="#0d6efd", fontweight="bold")
        ax.text(0.99, 0.97, "*** p < .001 all metrics (Mann-Whitney U)",
                transform=ax.transAxes, ha="right", va="top",
                fontsize=9, color="#198754", fontweight="bold")

    # Composite
    fig = plt.figure(figsize=(14, 10)); fig.patch.set_facecolor(BG)
    gs  = GridSpec(2, 3, hspace=0.5, wspace=0.38)
    ax1 = fig.add_subplot(gs[0, 0]); ax2 = fig.add_subplot(gs[0, 1])
    ax3 = fig.add_subplot(gs[0, 2]); ax4 = fig.add_subplot(gs[1, :])
    for ax in [ax1, ax2, ax3, ax4]: ax.set_facecolor(SF)
    _4a(ax1); _4b(ax2); _4c(ax3); _4d(ax4)
    ax1.set_title("Tie Type Distribution", fontsize=10, fontweight="bold", color=TX, pad=10)
    ax2.set_title("Sentiment by Tie Type", fontsize=10, fontweight="bold", color=TX, pad=10)
    ax3.set_title("Mean Compound Score", fontsize=10, fontweight="bold", color=TX, pad=10)
    ax4.set_title("Bridge vs. Non-Bridge Users: Centrality Comparison",
                  fontsize=10, fontweight="bold", color=TX, pad=10)
    fig.suptitle("Figure 4.4: Granovetter Weak Ties — Bridge Users and Sentiment × Tie Type",
                 fontsize=12, fontweight="bold", color=TX, y=1.01)
    save(os.path.join(FIG_DIR, "fig4_granovetter.png"))

    # Individual panels
    for fname, draw_fn, title, w, h in [
        ("fig4a_tie_type_donut.png",    _4a, "Figure 4.4a: Tie Type Distribution", 7, 6),
        ("fig4b_sentiment_by_tie.png",  _4b, "Figure 4.4b: Sentiment Distribution by Tie Type", 8, 5),
        ("fig4c_compound_score.png",    _4c, "Figure 4.4c: Mean RoBERTa Compound Score by Tie Type", 7, 5),
        ("fig4d_bridge_centrality.png", _4d, "Figure 4.4d: Bridge vs Non-Bridge — Centrality Comparison", 9, 5),
    ]:
        fig, ax = plt.subplots(figsize=(w, h)); fig.patch.set_facecolor(BG); ax.set_facecolor(SF)
        draw_fn(ax)
        ax.set_title(title, fontsize=12, fontweight="bold", color=TX, pad=10)
        plt.tight_layout(); save(os.path.join(FIG_DIR, fname))


# ══════════════════════════════════════════════════════════════════════════════
# FIG 5 — SENTIMENT (composite + 4 individual panels)
# ══════════════════════════════════════════════════════════════════════════════
def fig5_sentiment(nodes, comments):
    print("Generating Fig 5: Sentiment...")
    subs5    = ["AdMU","peyups","dlsu","Benilde"]
    pp5      = [24.5,20.9,20.7,24.2]
    np5      = [61.5,55.7,52.3,44.5]
    gp5      = [14.0,23.4,27.0,31.2]
    sub_ord  = ["AdMU","peyups","dlsu","Benilde"]

    def _5a(ax):
        wedges, txt, atxt = ax.pie(
            [6890, 16933, 6406],
            labels=["Positive\n22.8%","Neutral\n56.0%","Negative\n21.2%"],
            colors=["#198754","#6C757D","#dc3545"], startangle=90,
            autopct="%1.1f%%", pctdistance=0.72,
            wedgeprops=dict(width=0.6, edgecolor="white", lw=2.5))
        for t in txt:  t.set_color(TX);  t.set_fontsize(9)
        for t in atxt: t.set_color("white"); t.set_fontsize(9); t.set_fontweight("bold")
        ax.text(0, 0, "Mean:\n+0.0375", ha="center", va="center",
                fontsize=9, fontweight="bold", color=TX)

    def _5b(ax):
        for yi, (s, p_, n_, g_) in enumerate(zip(subs5, pp5, np5, gp5)):
            ax.barh(yi, p_, color="#198754", height=0.55, edgecolor="white", lw=0.5)
            ax.barh(yi, n_, left=p_, color="#6C757D", height=0.55, edgecolor="white", lw=0.5)
            ax.barh(yi, g_, left=p_+n_, color="#dc3545", height=0.55, edgecolor="white", lw=0.5)
            for xstart, pct, col in [(p_/2,p_,"#198754"),(p_+n_/2,n_,"#6C757D"),(p_+n_+g_/2,g_,"#dc3545")]:
                if pct > 7:
                    ax.text(xstart, yi, f"{pct:.1f}%", ha="center", va="center",
                            fontsize=8, color="white", fontweight="bold")
        ax.set_yticks(range(4)); ax.set_yticklabels([f"r/{s}" for s in subs5], fontsize=10, color=TX)
        ax.set_xlim(0, 100); ax.set_xlabel("% of comments", fontsize=9, color=MU)
        ax.xaxis.set_major_formatter(mticker.PercentFormatter())
        ax.legend(handles=[mpatches.Patch(color=c, label=l) for c, l in
            zip(["#198754","#6C757D","#dc3545"], ["Positive","Neutral","Negative"])],
            fontsize=8, facecolor="white", edgecolor=GR, loc="lower right")

    def _5c(ax):
        cv5 = nodes["mean_confidence"].dropna() if "mean_confidence" in nodes.columns else pd.Series([0.747]*100)
        ax.hist(cv5, bins=40, color="#6f42c1", alpha=0.82, edgecolor="white", lw=0.3)
        ax.axvline(0.60, color="#fd7e14", lw=2.2, ls="--", label="Reliability threshold (0.60)")
        ax.axvline(cv5.mean(), color="#198754", lw=2, ls="-.", label=f"Mean = {cv5.mean():.3f}")
        ax.set_xlabel("Max class probability", fontsize=9, color=MU)
        ax.set_ylabel("User count", fontsize=9, color=MU)
        ax.legend(fontsize=8, facecolor="white", edgecolor=GR)
        ax.text(0.02, 0.97, f"{(cv5>=0.60).mean()*100:.1f}% classified at high confidence (≥ 0.60)",
                transform=ax.transAxes, va="top", fontsize=8.5, color="#198754", fontweight="bold")

    def _5d(ax):
        if "mean_compound" in nodes.columns:
            ns_d = nodes[nodes["primary_subreddit"].isin(sub_ord)][
                ["primary_subreddit","mean_compound"]].dropna()
            bp_d = [ns_d[ns_d["primary_subreddit"]==s]["mean_compound"].clip(-1,1).values for s in sub_ord]
        else:
            bp_d = [np.random.normal(m, 0.3, 300) for m in [0.05, 0.03, 0.02, -0.01]]
        bp = ax.boxplot(bp_d, patch_artist=True, showfliers=False,
                        medianprops=dict(color="white", lw=2.2),
                        whiskerprops=dict(color=MU), capprops=dict(color=MU))
        for patch, s in zip(bp["boxes"], sub_ord):
            patch.set_facecolor(SUB_COLORS[s]); patch.set_alpha(0.78); patch.set_edgecolor(GR)
        ax.axhline(0, color=MU, lw=1, ls="--")
        ax.set_xticks(range(1, 5)); ax.set_xticklabels([f"r/{s}" for s in sub_ord], fontsize=9, color=TX)
        ax.set_ylabel("RoBERTa compound score", fontsize=9, color=MU)
        ax.set_ylim(-1.1, 1.1)

    # Composite
    fig = plt.figure(figsize=(14, 9)); fig.patch.set_facecolor(BG)
    gs  = GridSpec(2, 2, hspace=0.48, wspace=0.34)
    ax1 = fig.add_subplot(gs[0,0]); ax2 = fig.add_subplot(gs[0,1])
    ax3 = fig.add_subplot(gs[1,0]); ax4 = fig.add_subplot(gs[1,1])
    for ax in [ax1,ax2,ax3,ax4]: ax.set_facecolor(SF)
    _5a(ax1); _5b(ax2); _5c(ax3); _5d(ax4)
    ax1.set_title("Overall RoBERTa Sentiment\n(n = 30,229 comments)", fontsize=10, fontweight="bold", color=TX, pad=8)
    ax2.set_title("Sentiment Distribution by Subreddit",              fontsize=10, fontweight="bold", color=TX, pad=8)
    ax3.set_title("RoBERTa Classification Confidence",                fontsize=10, fontweight="bold", color=TX, pad=8)
    ax4.set_title("Compound Score Distribution by Subreddit",         fontsize=10, fontweight="bold", color=TX, pad=8)
    fig.suptitle("Figure 4.5: RoBERTa Sentiment Analysis Results (RQ2)",
                 fontsize=13, fontweight="bold", color=TX, y=1.01)
    save(os.path.join(FIG_DIR, "fig5_sentiment.png"))

    for fname, draw_fn, title, w, h in [
        ("fig5a_overall_sentiment.png",    _5a, "Figure 4.5a: Overall RoBERTa Sentiment Distribution\n(n = 30,229 comments)", 7, 6),
        ("fig5b_sentiment_by_subreddit.png",_5b,"Figure 4.5b: Sentiment Distribution by Subreddit", 9, 5),
        ("fig5c_confidence.png",           _5c, "Figure 4.5c: RoBERTa Classification Confidence Distribution", 8, 5),
        ("fig5d_compound_boxplot.png",     _5d, "Figure 4.5d: Compound Score Distribution by Subreddit", 8, 5),
    ]:
        fig, ax = plt.subplots(figsize=(w, h)); fig.patch.set_facecolor(BG); ax.set_facecolor(SF)
        draw_fn(ax)
        ax.set_title(title, fontsize=12, fontweight="bold", color=TX, pad=10)
        plt.tight_layout(); save(os.path.join(FIG_DIR, fname))


# ══════════════════════════════════════════════════════════════════════════════
# FIG 6 — TEMPORAL (composite + 5 individual panels)
# ══════════════════════════════════════════════════════════════════════════════
def fig6_temporal(comments, posts, edges):
    print("Generating Fig 6: Temporal dynamics...")
    subs6 = ["Benilde","dlsu","peyups","AdMU"]
    monthly = comments.groupby(["year_month","subreddit"]).size().unstack(fill_value=0)
    months_str = [str(m) for m in monthly.index]
    x6 = np.arange(len(months_str))

    def _time_series(ax):
        for sub in ["AdMU","peyups","dlsu","Benilde"]:
            if sub in monthly.columns:
                ax.plot(x6, monthly[sub], color=SUB_COLORS[sub], lw=2,
                        label=f"r/{sub}", zorder=3)
                ax.fill_between(x6, monthly[sub], alpha=0.07, color=SUB_COLORS[sub])
        ax.set_xticks([i for i in range(0, len(months_str), 3)])
        ax.set_xticklabels([months_str[i] for i in range(0,len(months_str),3)],
                           rotation=35, ha="right", fontsize=7.5)
        ax.set_ylabel("Comments per month", fontsize=9, color=MU)
        ax.legend(fontsize=9, facecolor="white", edgecolor=GR, loc="upper left")
        peaks = [(9,"Nov 2021\nACET"),(21,"Nov 2022\nACET"),(33,"Nov 2023\nExam"),(45,"May 2025\nACET")]
        for xp, lbl in peaks:
            if xp < len(months_str):
                ax.axvline(xp, color="#fd7e14", lw=1.2, ls=":", alpha=0.8)
                ax.text(xp + 0.3, ax.get_ylim()[1] * 0.9, lbl, fontsize=6.5, color="#fd7e14", va="top")

    def _top_threads(ax):
        top_t = posts.nlargest(10,"post_num_comments")[["post_title","subreddit","post_num_comments"]].reset_index(drop=True)
        bars6 = ax.barh(np.arange(len(top_t)), top_t["post_num_comments"],
                        color=[SUB_COLORS[s] for s in top_t["subreddit"]],
                        alpha=0.85, edgecolor="white", height=0.65)
        ax.set_yticks(np.arange(len(top_t)))
        ax.set_yticklabels([t[:42]+"…" if len(t)>42 else t for t in top_t["post_title"]],
                           fontsize=6.5, color=TX)
        ax.set_xlabel("Comment count", fontsize=9, color=MU)
        ax.invert_yaxis()
        handles6 = [mpatches.Patch(color=v, label=f"r/{k}") for k,v in SUB_COLORS.items() if k!="unknown"]
        ax.legend(handles=handles6, fontsize=8, facecolor="white", edgecolor=GR, loc="lower right")
        for bar in bars6:
            ax.text(bar.get_width()+25, bar.get_y()+bar.get_height()/2,
                    f"{int(bar.get_width()):,}", va="center", fontsize=8, color=TX, fontweight="bold")

    def _depth(ax):
        d0 = len(comments[comments["comment_depth"]==0])
        d1 = len(comments[comments["comment_depth"]==1])
        ax.bar([0,1],[d0,d1], color=["#fd7e14","#0d6efd"], alpha=0.85, edgecolor="white", width=0.5)
        ax.set_xticks([0,1])
        ax.set_xticklabels(["Depth 0\npost_reply\n(weak-tie layer)",
                            "Depth 1\ncomment_reply\n(strong-tie layer)"], fontsize=9, color=TX)
        ax.set_ylabel("Comment count", fontsize=9, color=MU)
        for i,(d,col) in enumerate([(d0,"#fd7e14"),(d1,"#0d6efd")]):
            pct = d/(d0+d1)*100
            ax.text(i, d+120, f"{d:,}\n({pct:.1f}%)", ha="center",
                    fontsize=9, color=col, fontweight="bold")

    def _upvote_ratio(ax):
        upv = [posts[posts["subreddit"]==s]["post_upvote_ratio"].dropna().values for s in subs6]
        bp = ax.boxplot(upv, patch_artist=True, showfliers=False,
                        medianprops=dict(color="white",lw=2.2),
                        whiskerprops=dict(color=MU), capprops=dict(color=MU))
        for patch,s in zip(bp["boxes"],subs6):
            patch.set_facecolor(SUB_COLORS[s]); patch.set_alpha(0.78); patch.set_edgecolor(GR)
        ax.set_xticks(range(1,5)); ax.set_xticklabels([f"r/{s}" for s in subs6], fontsize=9, color=TX)
        ax.set_ylabel("Post upvote ratio", fontsize=9, color=MU)
        ax.set_ylim(0, 1.05)

    def _edge_type(ax):
        pr = [len(edges[(edges["Subreddit"]==s)&(edges["EdgeType"]=="post_reply")]) for s in subs6]
        cr = [len(edges[(edges["Subreddit"]==s)&(edges["EdgeType"]=="comment_reply")]) for s in subs6]
        x5 = np.arange(4)
        ax.bar(x5, pr, color="#fd7e14", alpha=0.85, label="post_reply (weak)", edgecolor="white", lw=0.5)
        ax.bar(x5, cr, bottom=pr, color="#0d6efd", alpha=0.85, label="comment_reply (strong)", edgecolor="white", lw=0.5)
        ax.set_xticks(x5); ax.set_xticklabels([f"r/{s}" for s in subs6], fontsize=9, color=TX)
        ax.set_ylabel("Edge count", fontsize=9, color=MU)
        ax.legend(fontsize=8, facecolor="white", edgecolor=GR)
        for i,(p_,cr_) in enumerate(zip(pr,cr)):
            ax.text(i, p_+cr_+60, f"{p_+cr_:,}", ha="center", fontsize=8, color=TX, fontweight="bold")

    # Composite
    fig = plt.figure(figsize=(14, 10)); fig.patch.set_facecolor(BG)
    gs  = GridSpec(3, 2, hspace=0.55, wspace=0.34)
    ax1 = fig.add_subplot(gs[0,:]); ax2 = fig.add_subplot(gs[1,0])
    ax3 = fig.add_subplot(gs[1,1]); ax4 = fig.add_subplot(gs[2,0])
    ax5 = fig.add_subplot(gs[2,1])
    for ax in [ax1,ax2,ax3,ax4,ax5]: ax.set_facecolor(SF)
    _time_series(ax1); _top_threads(ax2); _depth(ax3); _upvote_ratio(ax4); _edge_type(ax5)
    ax1.set_title("Comment Volume Over Time by Subreddit (RQ3)", fontsize=11, fontweight="bold", color=TX, pad=8)
    ax2.set_title("Top 10 Threads by Comment Count",             fontsize=10, fontweight="bold", color=TX, pad=8)
    ax3.set_title("Reply Depth Distribution",                    fontsize=10, fontweight="bold", color=TX, pad=8)
    ax4.set_title("Post Upvote Ratio by Subreddit",              fontsize=10, fontweight="bold", color=TX, pad=8)
    ax5.set_title("Interaction Type by Subreddit",               fontsize=10, fontweight="bold", color=TX, pad=8)
    fig.suptitle("Figure 4.6: Temporal Interaction Dynamics and Amplification Metrics (RQ3)",
                 fontsize=12, fontweight="bold", color=TX, y=1.01)
    save(os.path.join(FIG_DIR, "fig6_temporal.png"))

    for fname, draw_fn, title, w, h in [
        ("fig6a_volume_over_time.png", _time_series, "Figure 4.6a: Comment Volume Over Time by Subreddit", 13, 5),
        ("fig6b_top_threads.png",      _top_threads,  "Figure 4.6b: Top 10 Threads by Comment Count",      10, 6),
        ("fig6c_reply_depth.png",      _depth,        "Figure 4.6c: Reply Depth Distribution",              7,  5),
        ("fig6d_upvote_ratio.png",     _upvote_ratio, "Figure 4.6d: Post Upvote Ratio by Subreddit",        8,  5),
        ("fig6e_edge_type.png",        _edge_type,    "Figure 4.6e: Interaction Type by Subreddit",         8,  5),
    ]:
        fig, ax = plt.subplots(figsize=(w, h)); fig.patch.set_facecolor(BG); ax.set_facecolor(SF)
        draw_fn(ax)
        ax.set_title(title, fontsize=12, fontweight="bold", color=TX, pad=10)
        plt.tight_layout(); save(os.path.join(FIG_DIR, fname))


# ══════════════════════════════════════════════════════════════════════════════
# FIG 7 — AMPLIFICATION (composite + 6 individual panels)
# ══════════════════════════════════════════════════════════════════════════════
def fig7_amplification(nodes, comments, posts, edges):
    print("Generating Fig 7: Amplification metrics...")
    subs7 = ["Benilde","dlsu","peyups","AdMU"]
    uv  = nodes["total_upvotes_received"].clip(0, 500)
    wr  = nodes["weak_tie_ratio"].dropna()

    def _7a(ax):
        ax.hist(uv[uv>0], bins=60, color="#fd7e14", alpha=0.82, edgecolor="white", lw=0.3)
        ax.set_yscale("log")
        ax.axvline(uv.mean(),   color="#0d6efd", lw=2, ls="--", label=f"Mean = {uv.mean():.1f}")
        ax.axvline(uv.median(), color="#198754", lw=2, ls="-.", label=f"Median = {uv.median():.0f}")
        ax.set_xlabel("Total upvotes received (clipped ≤ 500)", fontsize=9, color=MU)
        ax.set_ylabel("User count (log scale)", fontsize=9, color=MU)
        ax.legend(fontsize=8, facecolor="white", edgecolor=GR)

    def _7b(ax):
        ax.hist(wr, bins=30, color="#fd7e14", alpha=0.82, edgecolor="white", lw=0.3)
        ax.axvline(0.5, color=TX, lw=1.8, ls="--", alpha=0.7, label="50% threshold")
        ax.set_xlabel("Proportion of comments that are weak-tie", fontsize=9, color=MU)
        ax.set_ylabel("User count", fontsize=9, color=MU)
        ax.legend(fontsize=8, facecolor="white", edgecolor=GR)
        ax.text(0.97, 0.96, f"{(wr>0.5).mean()*100:.1f}% of users > 50% weak tie",
                transform=ax.transAxes, ha="right", va="top", fontsize=8.5,
                color="#fd7e14", fontweight="bold")

    def _7c(ax):
        means7 = [posts[posts["subreddit"]==s]["post_num_comments"].mean() for s in subs7]
        maxes7 = [posts[posts["subreddit"]==s]["post_num_comments"].max()  for s in subs7]
        ax.bar(range(4), means7, color=[SUB_COLORS[s] for s in subs7], alpha=0.85, edgecolor="white")
        ax.set_yscale("log")
        axb = ax.twinx()
        axb.plot(range(4), maxes7, "D--", color="#6f42c1", lw=2, ms=8)
        axb.set_ylabel("Max thread length", color="#6f42c1", fontsize=9)
        axb.tick_params(colors="#6f42c1")
        for sp in ["top","right","left","bottom"]: axb.spines[sp].set_color(GR)
        ax.set_xticks(range(4)); ax.set_xticklabels([f"r/{s}" for s in subs7], fontsize=9, color=TX)
        ax.set_ylabel("Mean thread length (log)", fontsize=9, color=MU)
        for i,m in enumerate(means7): ax.text(i, m*1.12, f"{m:.1f}", ha="center", fontsize=8, color=TX)

    def _7d(ax):
        tn = nodes.nlargest(150, "betweenness_centrality").copy()
        sc_c = [SUB_COLORS.get(str(s), "#adb5bd") for s in tn["primary_subreddit"]]
        ax.scatter(tn["betweenness_centrality"], tn["total_upvotes_received"].clip(-50, 500),
                   c=sc_c, s=50, alpha=0.72, edgecolors="none", zorder=3)
        ax.axhline(0, color=MU, lw=0.8, ls="--")
        ax.set_xlabel("Betweenness centrality", fontsize=9, color=MU)
        ax.set_ylabel("Total upvotes received", fontsize=9, color=MU)
        handles7 = [mpatches.Patch(color=v, label=f"r/{k}") for k,v in SUB_COLORS.items() if k!="unknown"]
        ax.legend(handles=handles7, fontsize=8, facecolor="white", edgecolor=GR)

    def _7e(ax):
        ws = comments[comments["tie_type"]=="weak"]["comment_score"].clip(-20,100)
        ss = comments[comments["tie_type"]=="strong"]["comment_score"].clip(-20,100)
        ax.hist(ws, bins=40, color="#fd7e14", alpha=0.65, label="Weak tie",   density=True, edgecolor="none")
        ax.hist(ss, bins=40, color="#0d6efd", alpha=0.65, label="Strong tie", density=True, edgecolor="none")
        ax.axvline(ws.mean(), color="#fd7e14", lw=2, ls="--", label=f"Weak mean = {ws.mean():.2f}")
        ax.axvline(ss.mean(), color="#0d6efd", lw=2, ls="--", label=f"Strong mean = {ss.mean():.2f}")
        ax.set_xlabel("Comment score (clipped −20 to 100)", fontsize=9, color=MU)
        ax.set_ylabel("Density", fontsize=9, color=MU)
        ax.legend(fontsize=8, facecolor="white", edgecolor=GR)

    def _7f(ax):
        subs8 = ["Benilde","dlsu","peyups","AdMU","MERGED"]
        cv8   = [0.0528,0.0550,0.0466,0.1449,0.0764]
        cols8 = [SUB_COLORS["Benilde"],SUB_COLORS["dlsu"],SUB_COLORS["peyups"],
                 SUB_COLORS["AdMU"],"#adb5bd"]
        bs8 = ax.bar(range(5), cv8, color=cols8, alpha=0.85, edgecolor="white", lw=0.5)
        bs8[3].set_edgecolor("#212529"); bs8[3].set_linewidth(2.5)
        ax.set_xticks(range(5)); ax.set_xticklabels([f"r/{s}" for s in subs8], fontsize=9, color=TX, rotation=10)
        ax.set_ylabel("Clustering coefficient", fontsize=9, color=MU)
        for i,v in enumerate(cv8): ax.text(i, v+0.002, f"{v:.4f}", ha="center", va="bottom", fontsize=8, color=TX)
        ax.text(3, cv8[3]+0.010, "★  3× avg", ha="center", fontsize=10, color="#fd7e14", fontweight="bold")

    # Composite
    fig = plt.figure(figsize=(14, 9)); fig.patch.set_facecolor(BG)
    gs  = GridSpec(2, 3, hspace=0.5, wspace=0.36)
    axs = [fig.add_subplot(gs[i//3, i%3]) for i in range(6)]
    for ax in axs: ax.set_facecolor(SF)
    draws = [_7a, _7b, _7c, _7d, _7e, _7f]
    titles_7 = [
        "Total Upvotes Received",    "Weak Tie Ratio per User",
        "Thread Length by Subreddit","Betweenness vs Upvotes (Top-150)",
        "Comment Score by Tie Type", "Clustering Coefficient Comparison",
    ]
    for ax, draw_fn, title in zip(axs, draws, titles_7):
        draw_fn(ax)
        ax.set_title(title, fontsize=10, fontweight="bold", color=TX, pad=8)
    fig.suptitle("Figure 4.7: Interaction Amplification and Tie Strength Metrics (RQ3)",
                 fontsize=12, fontweight="bold", color=TX, y=1.01)
    save(os.path.join(FIG_DIR, "fig7_amplification.png"))

    for fname, draw_fn, title, w, h in [
        ("fig7a_upvote_dist.png",         _7a, "Figure 4.7a: Total Upvotes Received per User",                8, 5),
        ("fig7b_weak_tie_ratio.png",      _7b, "Figure 4.7b: Weak Tie Ratio Distribution per User",           8, 5),
        ("fig7c_thread_length.png",       _7c, "Figure 4.7c: Thread Length by Subreddit",                     8, 5),
        ("fig7d_betweenness_upvotes.png", _7d, "Figure 4.7d: Betweenness Centrality vs Total Upvotes",        8, 5),
        ("fig7e_comment_score_tie.png",   _7e, "Figure 4.7e: Comment Score Distribution by Tie Type",         8, 5),
        ("fig7f_clustering.png",          _7f, "Figure 4.7f: Clustering Coefficient — All Subreddits vs Merged", 8, 5),
    ]:
        fig, ax = plt.subplots(figsize=(w, h)); fig.patch.set_facecolor(BG); ax.set_facecolor(SF)
        draw_fn(ax)
        ax.set_title(title, fontsize=12, fontweight="bold", color=TX, pad=10)
        plt.tight_layout(); save(os.path.join(FIG_DIR, fname))


# ── Main ──────────────────────────────────────────────────────────────────────
def generate_all_figures():
    os.makedirs(FIG_DIR, exist_ok=True)
    set_style()

    print("Loading data...")
    nodes, edges, comments, posts = load_data()

    fig1_network_map(nodes, edges)
    fig2_centrality(nodes)
    fig3_per_hei()
    fig4_granovetter()
    fig5_sentiment(nodes, comments)
    fig6_temporal(comments, posts, edges)
    fig7_amplification(nodes, comments, posts, edges)

    print(f"\nAll figures saved to {FIG_DIR}/")
    all_figs = [f for f in os.listdir(FIG_DIR) if f.endswith(".png")]
    all_figs.sort()
    print(f"Total figures generated: {len(all_figs)}")
    for f in all_figs:
        print(f"  {f}")


if __name__ == "__main__":
    generate_all_figures()
